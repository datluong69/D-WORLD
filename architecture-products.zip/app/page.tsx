"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import {
  Brain,
  Camera,
  ChevronRight,
  Compass,
  Database,
  DollarSign,
  Globe,
  Lightbulb,
  MessageSquare,
  Search,
  ShoppingCart,
  Users,
  HeadsetIcon as VrHeadset,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"

export default function DWorldApp() {
  const router = useRouter()
  const [budget, setBudget] = useState(500000000)
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoaded, setIsLoaded] = useState(false)
  const [activeTab, setActiveTab] = useState("creative-architect")

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const handleFeatureClick = (feature: string) => {
    router.push(`/features/${feature}`)
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(value)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: "spring", stiffness: 100 },
    },
  }

  const fadeIn = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.6 } },
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <motion.header
        className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white relative overflow-hidden"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          {isLoaded &&
            Array.from({ length: 20 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute rounded-full bg-white/10"
                initial={{
                  x: Math.random() * 100 - 50 + "%",
                  y: Math.random() * 100 + "%",
                  scale: Math.random() * 0.5 + 0.5,
                  opacity: Math.random() * 0.5,
                }}
                animate={{
                  y: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
                  opacity: [Math.random() * 0.3, Math.random() * 0.5],
                }}
                transition={{
                  duration: Math.random() * 20 + 10,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatType: "reverse",
                }}
                style={{
                  width: Math.random() * 300 + 50,
                  height: Math.random() * 300 + 50,
                }}
              />
            ))}
        </div>

        <div className="container mx-auto px-4 py-6 relative z-10">
          <div className="flex items-center justify-between">
            <motion.div
              className="flex items-center gap-2"
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="bg-white/10 p-2 rounded-lg backdrop-blur-sm">
                <Brain className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold">D WORLD</h1>
            </motion.div>
            <div className="hidden md:flex items-center gap-6">
              {["Trang chủ", "Khám phá", "Marketplace", "Đầu tư", "Cộng đồng"].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ y: -20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.1 * index, duration: 0.5 }}
                >
                  <Link href="#" className="text-white/80 hover:text-white transition">
                    {item}
                  </Link>
                </motion.div>
              ))}
            </div>
            <motion.div
              className="flex items-center gap-3"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Button variant="ghost" className="text-white border border-white/20 hover:bg-white/10">
                Đăng nhập
              </Button>
              <Button className="bg-white text-purple-700 hover:bg-white/90">Đăng ký</Button>
            </motion.div>
          </div>

          <motion.div
            className="mt-16 mb-12 text-center max-w-3xl mx-auto"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <motion.h2 className="text-4xl md:text-5xl font-bold mb-6" variants={itemVariants}>
              Nền tảng đổi mới sáng tạo toàn diện
            </motion.h2>
            <motion.p className="text-lg text-white/80 mb-8" variants={itemVariants}>
              Kết nối với cơ sở dữ liệu bách khoa, AI hỗ trợ nghiên cứu, và hệ sinh thái đầu tư toàn cầu
            </motion.p>
            <motion.div className="relative max-w-2xl mx-auto" variants={itemVariants}>
              <Input
                className="w-full py-6 pl-12 pr-4 rounded-full text-gray-800 text-lg"
                placeholder="Nhập ý tưởng, sản phẩm hoặc công nghệ bạn muốn tìm hiểu..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Button
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-opacity"
                onClick={() => router.push(`/search?q=${encodeURIComponent(searchQuery)}`)}
              >
                Tìm kiếm
              </Button>
            </motion.div>

            {/* Budget slider */}
            <motion.div
              className="mt-8 bg-white/10 backdrop-blur-sm p-6 rounded-xl max-w-2xl mx-auto"
              variants={itemVariants}
            >
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-medium">Ngân sách của bạn</h3>
                <Badge variant="outline" className="bg-white/20 text-white">
                  {formatCurrency(budget)}
                </Badge>
              </div>
              <Slider
                defaultValue={[budget]}
                max={2000000000}
                step={10000000}
                onValueChange={(value) => setBudget(value[0])}
                className="my-4"
              />
              <div className="flex justify-between text-sm text-white/70">
                <span>50 triệu</span>
                <span>500 triệu</span>
                <span>1 tỷ</span>
                <span>2 tỷ</span>
              </div>
              <div className="mt-4 flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1 border-white/20 text-white hover:bg-white/10"
                  onClick={() => router.push(`/budget-analysis?amount=${budget}`)}
                >
                  Phân tích khả thi
                </Button>
                <Button
                  className="flex-1 bg-white text-purple-700 hover:bg-white/90"
                  onClick={() => router.push(`/recommendations?budget=${budget}`)}
                >
                  Đề xuất dự án
                </Button>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12 -mt-12 relative z-20">
        {/* Feature Cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {[
            {
              icon: <Database className="h-6 w-6 text-blue-600" />,
              title: "Cơ sở dữ liệu bách khoa toàn thư",
              description:
                "Chứa thông tin về tất cả nguyên vật liệu, công nghệ, phương pháp chế tạo, từ những thứ phổ biến đến những thứ ít ai biết.",
              color: "blue",
              route: "encyclopedia",
            },
            {
              icon: <Brain className="h-6 w-6 text-purple-600" />,
              title: "AI hỗ trợ nghiên cứu & thiết kế",
              description:
                "Khi bạn nhập ý tưởng, số tiền, khu vực, AI sẽ tự động lọc ra nguyên vật liệu phù hợp và tạo hướng dẫn chế tạo.",
              color: "purple",
              route: "ai-research",
            },
            {
              icon: <ShoppingCart className="h-6 w-6 text-indigo-600" />,
              title: "Tích hợp thị trường cung ứng",
              description:
                "Kết nối với các nhà cung cấp nguyên vật liệu, phòng thí nghiệm, xưởng chế tạo và đặt mua trực tiếp trên nền tảng.",
              color: "indigo",
              route: "marketplace",
            },
          ].map((feature, index) => (
            <motion.div key={index} variants={itemVariants} whileHover={{ y: -5, transition: { duration: 0.2 } }}>
              <Card className="bg-white shadow-md border-0 h-full overflow-hidden group">
                <CardHeader className="pb-2">
                  <div
                    className={`w-12 h-12 rounded-full bg-${feature.color}-100 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                  >
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
                <CardFooter>
                  <Button
                    variant="ghost"
                    className={`text-${feature.color}-600 p-0 flex items-center gap-1 group-hover:gap-2 transition-all`}
                    onClick={() => handleFeatureClick(feature.route)}
                  >
                    Khám phá ngay <ChevronRight className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Main Features Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mb-16"
        >
          <Tabs defaultValue="creative-architect" className="mb-16" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 md:grid-cols-6 bg-gray-100 p-1 rounded-lg mb-8">
              {[
                {
                  value: "creative-architect",
                  icon: <Lightbulb className="h-4 w-4 mr-2" />,
                  label: "Kiến trúc sư sáng tạo",
                },
                { value: "marketplace", icon: <ShoppingCart className="h-4 w-4 mr-2" />, label: "Chợ công nghệ" },
                { value: "feasibility", icon: <Compass className="h-4 w-4 mr-2" />, label: "Kiểm tra khả thi" },
                { value: "experts", icon: <Globe className="h-4 w-4 mr-2" />, label: "Chuyên gia toàn cầu" },
                { value: "ar-vr", icon: <VrHeadset className="h-4 w-4 mr-2" />, label: "AR/VR" },
                { value: "funding", icon: <DollarSign className="h-4 w-4 mr-2" />, label: "Huy động vốn" },
              ].map((tab) => (
                <TabsTrigger
                  key={tab.value}
                  value={tab.value}
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white transition-all duration-300"
                >
                  {tab.icon}
                  <span className="hidden sm:inline">{tab.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value="creative-architect" className="mt-0">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-800">AI "kiến trúc sư sáng tạo"</h3>
                  <p className="text-gray-600 mb-6">
                    Không chỉ tra cứu nguyên vật liệu, AI sẽ đề xuất giải pháp sáng tạo dựa trên công nghệ mới nhất. Ví
                    dụ: Nếu muốn chế tạo một thiết bị bay cá nhân, AI sẽ gợi ý các nguyên lý khoa học phù hợp, vật liệu
                    tốt nhất và hướng đi thực tiễn.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Rút ngắn thời gian R&D.</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">
                        Khuyến khích sáng tạo, giúp phát triển các sản phẩm mang tính đột phá.
                      </p>
                    </div>
                  </div>
                  <Button
                    className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                    onClick={() => router.push("/features/ai-architect")}
                  >
                    Thử nghiệm ý tưởng
                  </Button>
                </div>
                <motion.div
                  className="bg-gray-100 p-6 rounded-xl"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="bg-white rounded-lg p-4 shadow-sm mb-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                        <Brain className="h-4 w-4 text-purple-600" />
                      </div>
                      <p className="font-medium text-gray-800">AI Kiến trúc sư</p>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">
                      Hãy mô tả ý tưởng sản phẩm của bạn, tôi sẽ gợi ý giải pháp công nghệ phù hợp.
                    </p>
                    <motion.div
                      className="bg-gray-50 p-3 rounded-lg mb-3"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.4 }}
                    >
                      <p className="text-gray-700">
                        Tôi muốn chế tạo một thiết bị lọc nước di động sử dụng năng lượng mặt trời, có thể hoạt động ở
                        vùng sâu vùng xa.
                      </p>
                    </motion.div>
                    <motion.div
                      className="bg-purple-50 p-3 rounded-lg"
                      initial={{ opacity: 0, height: 0, overflow: "hidden" }}
                      animate={{ opacity: 1, height: "auto" }}
                      transition={{ delay: 0.8, duration: 0.5 }}
                    >
                      <p className="text-gray-700">Dựa trên yêu cầu của bạn, tôi đề xuất:</p>
                      <ul className="list-disc pl-5 mt-2 space-y-1 text-gray-700">
                        <motion.li initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.0 }}>
                          Sử dụng màng lọc graphene oxide cải tiến (hiệu suất cao, chi phí thấp)
                        </motion.li>
                        <motion.li initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }}>
                          Tấm pin mặt trời dẻo CIGS (hiệu suất 20%, nhẹ, gập được)
                        </motion.li>
                        <motion.li initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.4 }}>
                          Hệ thống UV-LED diệt khuẩn tiết kiệm năng lượng
                        </motion.li>
                        <motion.li initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6 }}>
                          Vỏ thiết bị từ nhựa sinh học phân hủy được
                        </motion.li>
                      </ul>
                      <Button
                        className="mt-4 w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                        onClick={() => router.push("/features/ai-architect/water-filter")}
                      >
                        Xem chi tiết & Hướng dẫn
                      </Button>
                    </motion.div>
                  </div>
                </motion.div>
              </motion.div>
            </TabsContent>

            <TabsContent value="marketplace" className="mt-0">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-800">Chợ giao dịch công nghệ & nguyên vật liệu</h3>
                  <p className="text-gray-600 mb-6">
                    Tích hợp marketplace B2B để các doanh nghiệp và cá nhân có thể mua/bán nguyên vật liệu, linh kiện dễ
                    dàng. Người dùng có thể tra cứu giá cả, đánh giá nhà cung ứng, đàm phán trực tiếp qua nền tảng.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Tăng tính thực tiễn cho nền tảng.</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Giúp các startup & nhà sáng chế dễ tiếp cận nguyên liệu hơn.</p>
                    </div>
                  </div>
                  <Button
                    className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                    onClick={() => router.push("/features/marketplace")}
                  >
                    Khám phá thị trường
                  </Button>
                </div>
                <motion.div
                  className="bg-gray-100 p-6 rounded-xl"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="bg-white rounded-lg shadow-sm">
                    <div className="p-4 border-b">
                      <h4 className="font-medium text-gray-800">Nguyên vật liệu phổ biến</h4>
                    </div>
                    <div className="p-4 space-y-3">
                      {[
                        { name: "Graphene oxide", price: "1.200.000 VNĐ/kg", supplier: "TechMat Vietnam", rating: 4.8 },
                        {
                          name: "Pin mặt trời CIGS",
                          price: "3.500.000 VNĐ/m²",
                          supplier: "SolarTech Global",
                          rating: 4.6,
                        },
                        { name: "Màng lọc nano bạc", price: "850.000 VNĐ/m²", supplier: "NanoFilter Co.", rating: 4.9 },
                      ].map((item, index) => (
                        <motion.div
                          key={index}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors cursor-pointer"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.3 + index * 0.2 }}
                          whileHover={{ scale: 1.02 }}
                          onClick={() =>
                            router.push(`/features/marketplace/product/${item.name.toLowerCase().replace(/\s+/g, "-")}`)
                          }
                        >
                          <div>
                            <p className="font-medium text-gray-800">{item.name}</p>
                            <p className="text-sm text-gray-500">
                              {item.supplier} • ⭐ {item.rating}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-gray-800">{item.price}</p>
                            <Button variant="outline" size="sm" className="mt-1">
                              Mua ngay
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                      <Button className="w-full mt-2" onClick={() => router.push("/features/marketplace/materials")}>
                        Xem tất cả nguyên vật liệu
                      </Button>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            </TabsContent>

            <TabsContent value="feasibility" className="mt-0">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-800">Hệ thống AI kiểm tra khả thi của dự án</h3>
                  <p className="text-gray-600 mb-6">
                    Khi có ý tưởng, AI sẽ tự động phân tích tính khả thi dựa trên dữ liệu khoa học & kinh tế. Xem xét
                    nguyên vật liệu có sẵn không, chi phí sản xuất bao nhiêu, công nghệ nào có thể hỗ trợ và ai là đối
                    tác tiềm năng.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Giảm rủi ro thất bại.</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">
                        Giúp startup biết có nên đầu tư hay không trước khi bắt tay vào làm.
                      </p>
                    </div>
                  </div>
                  <Button
                    className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                    onClick={() => router.push("/features/feasibility")}
                  >
                    Phân tích dự án
                  </Button>
                </div>
                <motion.div
                  className="bg-gray-100 p-6 rounded-xl"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="bg-white rounded-lg shadow-sm p-4">
                    <h4 className="font-medium text-gray-800 mb-4">
                      Báo cáo khả thi: Thiết bị lọc nước năng lượng mặt trời
                    </h4>

                    <div className="space-y-4">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 0.5, delay: 0.3 }}
                      >
                        <p className="text-sm font-medium text-gray-500 mb-1">Khả thi về công nghệ</p>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <motion.div
                            className="bg-green-600 h-2.5 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: "85%" }}
                            transition={{ duration: 1, delay: 0.5 }}
                          ></motion.div>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">85% - Công nghệ hiện có sẵn và đã được chứng minh</p>
                      </motion.div>

                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 0.5, delay: 0.6 }}
                      >
                        <p className="text-sm font-medium text-gray-500 mb-1">Khả thi về kinh tế</p>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <motion.div
                            className="bg-yellow-500 h-2.5 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: "70%" }}
                            transition={{ duration: 1, delay: 0.8 }}
                          ></motion.div>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          70% - Chi phí sản xuất hợp lý, ROI dự kiến 18 tháng
                        </p>
                      </motion.div>

                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 0.5, delay: 0.9 }}
                      >
                        <p className="text-sm font-medium text-gray-500 mb-1">Khả thi về thị trường</p>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <motion.div
                            className="bg-green-600 h-2.5 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: "90%" }}
                            transition={{ duration: 1, delay: 1.1 }}
                          ></motion.div>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          90% - Nhu cầu cao tại các vùng nông thôn và vùng thiên tai
                        </p>
                      </motion.div>

                      <motion.div
                        className="p-3 bg-blue-50 rounded-lg text-sm text-gray-700"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.5, delay: 1.3 }}
                      >
                        <p className="font-medium mb-1">Đề xuất:</p>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Tìm kiếm đối tác sản xuất tại Việt Nam để giảm chi phí</li>
                          <li>Xem xét mô hình kinh doanh B2G để tiếp cận các chương trình nước sạch</li>
                          <li>Đăng ký bảo hộ sở hữu trí tuệ trước khi triển khai</li>
                        </ul>
                      </motion.div>

                      <Button
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                        onClick={() => router.push("/features/feasibility/water-filter-report")}
                      >
                        Xem báo cáo chi tiết
                      </Button>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            </TabsContent>

            <TabsContent value="experts" className="mt-0">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-800">
                    Kết nối với viện nghiên cứu & chuyên gia toàn cầu
                  </h3>
                  <p className="text-gray-600 mb-6">
                    Xây dựng hệ thống cố vấn trực tuyến với các chuyên gia, nhà khoa học, kỹ sư từ các viện nghiên cứu
                    hàng đầu. Khi gặp vấn đề khó, startup có thể đặt câu hỏi và nhận tư vấn trực tiếp.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Đẩy nhanh quá trình nghiên cứu & phát triển sản phẩm.</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Hỗ trợ startup tiếp cận tri thức từ các chuyên gia hàng đầu.</p>
                    </div>
                  </div>
                  <Button
                    className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                    onClick={() => router.push("/features/experts")}
                  >
                    Tìm chuyên gia
                  </Button>
                </div>
                <motion.div
                  className="bg-gray-100 p-6 rounded-xl"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="bg-white rounded-lg shadow-sm">
                    <div className="p-4 border-b">
                      <h4 className="font-medium text-gray-800">Chuyên gia hàng đầu</h4>
                    </div>
                    <div className="p-4 space-y-4">
                      {[
                        {
                          name: "TS. Nguyễn Văn A",
                          role: "Chuyên gia vật liệu nano",
                          org: "Đại học Bách Khoa Hà Nội",
                          img: "/placeholder.svg?height=50&width=50",
                        },
                        {
                          name: "GS. John Smith",
                          role: "Chuyên gia năng lượng tái tạo",
                          org: "MIT, Hoa Kỳ",
                          img: "/placeholder.svg?height=50&width=50",
                        },
                        {
                          name: "TS. Trần Minh B",
                          role: "Chuyên gia xử lý nước",
                          org: "Viện Khoa học Công nghệ Việt Nam",
                          img: "/placeholder.svg?height=50&width=50",
                        },
                      ].map((expert, index) => (
                        <motion.div
                          key={index}
                          className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors cursor-pointer"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.3 + index * 0.2 }}
                          whileHover={{ scale: 1.02 }}
                          onClick={() =>
                            router.push(`/features/experts/${expert.name.toLowerCase().replace(/\s+/g, "-")}`)
                          }
                        >
                          <div className="relative w-12 h-12 rounded-full overflow-hidden">
                            <Image
                              src={expert.img || "/placeholder.svg"}
                              alt={expert.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{expert.name}</p>
                            <p className="text-sm text-gray-500">{expert.role}</p>
                            <p className="text-xs text-gray-400">{expert.org}</p>
                          </div>
                          <Button variant="outline" size="sm" className="ml-auto">
                            Kết nối
                          </Button>
                        </motion.div>
                      ))}
                      <Button className="w-full" onClick={() => router.push("/features/experts/all")}>
                        Xem tất cả chuyên gia
                      </Button>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            </TabsContent>

            <TabsContent value="ar-vr" className="mt-0">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-800">
                    Công nghệ thực tế ảo (AR/VR) để mô phỏng sản phẩm
                  </h3>
                  <p className="text-gray-600 mb-6">
                    Trước khi sản xuất, người dùng có thể dùng AR/VR để xem mô hình 3D của sản phẩm và thử nghiệm tính
                    năng. Ví dụ: Nếu muốn tạo một loại pin mới, có thể mô phỏng cách nó hoạt động mà không cần sản xuất
                    thật.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Tiết kiệm chi phí thử nghiệm.</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Giúp nhà đầu tư dễ dàng hình dung tiềm năng của dự án.</p>
                    </div>
                  </div>
                  <Button
                    className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                    onClick={() => router.push("/features/ar-vr")}
                  >
                    Trải nghiệm AR/VR
                  </Button>
                </div>
                <motion.div
                  className="bg-gray-100 p-6 rounded-xl"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <motion.div
                      className="aspect-video relative bg-gray-800"
                      whileHover={{ scale: 1.02 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <motion.div
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ duration: 0.5, delay: 0.4 }}
                          >
                            <VrHeadset className="h-16 w-16 text-white/50 mx-auto mb-4" />
                          </motion.div>
                          <p className="text-white/80">Mô phỏng 3D thiết bị lọc nước năng lượng mặt trời</p>
                          <Button
                            className="mt-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                            onClick={() => router.push("/features/ar-vr/water-filter-3d")}
                          >
                            Xem mô phỏng 3D
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                    <div className="p-4">
                      <h4 className="font-medium text-gray-800 mb-2">Mô phỏng sản phẩm với AR/VR</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Xem trước thiết kế, kiểm tra tính năng và đánh giá hiệu suất trước khi sản xuất thực tế.
                      </p>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => router.push("/features/ar-vr/download-app")}
                        >
                          Tải ứng dụng AR
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => router.push("/features/ar-vr/web-view")}
                        >
                          Xem trên web
                        </Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            </TabsContent>

            <TabsContent value="funding" className="mt-0">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-800">Huy động vốn theo mô hình "Shark Tank ảo"</h3>
                  <p className="text-gray-600 mb-6">
                    Kết nối startup với nhà đầu tư theo hình thức đấu giá gọi vốn. Startup có thể thuyết trình online,
                    nhà đầu tư ra giá và tài trợ trực tiếp qua nền tảng.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Giúp startup huy động vốn nhanh hơn.</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <p className="text-gray-700">Nhà đầu tư tiếp cận được các dự án tiềm năng dễ dàng hơn.</p>
                    </div>
                  </div>
                  <Button
                    className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                    onClick={() => router.push("/features/funding")}
                  >
                    Đăng ký gọi vốn
                  </Button>
                </div>
                <motion.div
                  className="bg-gray-100 p-6 rounded-xl"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="bg-white rounded-lg shadow-sm">
                    <div className="p-4 border-b">
                      <h4 className="font-medium text-gray-800">Các dự án đang gọi vốn</h4>
                    </div>
                    <div className="p-4 space-y-4">
                      {[
                        {
                          name: "AquaSolar",
                          desc: "Thiết bị lọc nước năng lượng mặt trời",
                          goal: "500.000.000 VNĐ",
                          raised: "320.000.000 VNĐ",
                          percent: 64,
                        },
                        {
                          name: "EcoFilter",
                          desc: "Màng lọc sinh học phân hủy được",
                          goal: "300.000.000 VNĐ",
                          raised: "210.000.000 VNĐ",
                          percent: 70,
                        },
                        {
                          name: "SolarPack",
                          desc: "Pin mặt trời dạng túi gấp gọn",
                          goal: "800.000.000 VNĐ",
                          raised: "350.000.000 VNĐ",
                          percent: 44,
                        },
                      ].map((project, index) => (
                        <motion.div
                          key={index}
                          className="p-3 bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors cursor-pointer"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.3 + index * 0.2 }}
                          whileHover={{ scale: 1.02 }}
                          onClick={() => router.push(`/features/funding/project/${project.name.toLowerCase()}`)}
                        >
                          <div className="flex justify-between mb-2">
                            <div>
                              <p className="font-medium text-gray-800">{project.name}</p>
                              <p className="text-sm text-gray-500">{project.desc}</p>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                router.push(`/features/funding/invest/${project.name.toLowerCase()}`)
                              }}
                            >
                              Đầu tư
                            </Button>
                          </div>
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span className="text-gray-500">Đã gọi: {project.raised}</span>
                              <span className="text-gray-500">Mục tiêu: {project.goal}</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <motion.div
                                className="bg-blue-600 h-2 rounded-full"
                                initial={{ width: 0 }}
                                animate={{ width: `${project.percent}%` }}
                                transition={{ duration: 1, delay: 0.5 + index * 0.2 }}
                              ></motion.div>
                            </div>
                            <p className="text-xs text-right text-gray-500">{project.percent}%</p>
                          </div>
                        </motion.div>
                      ))}
                      <Button className="w-full" onClick={() => router.push("/features/funding/all-projects")}>
                        Xem tất cả dự án
                      </Button>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Additional Features */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          transition={{ delay: 0.6 }}
        >
          {[
            {
              icon: <MessageSquare className="h-6 w-6 text-blue-600" />,
              title: "Chat & kết nối trực tiếp",
              description:
                "Trò chuyện & thương lượng giá cả, điều kiện giao hàng với nhà cung ứng. AI hỗ trợ dịch thuật tự động nếu giao dịch với nhà cung ứng nước ngoài.",
              color: "blue",
              route: "chat",
            },
            {
              icon: <Users className="h-6 w-6 text-purple-600" />,
              title: "Tính năng Premium & đầu tư",
              description:
                "Người dùng Premium có thể kết nối với nhà đầu tư hoặc những người có cùng hứng thú để gọi vốn ngay trên nền tảng.",
              color: "purple",
              route: "premium",
            },
            {
              icon: <Camera className="h-6 w-6 text-indigo-600" />,
              title: "Đánh giá môi trường xung quanh",
              description:
                "Dùng AI & Camera điện thoại để quét môi trường xung quanh. Đánh giá xem có phù hợp để sản xuất, thử nghiệm hay không.",
              color: "indigo",
              route: "environment",
            },
          ].map((feature, index) => (
            <motion.div key={index} variants={itemVariants} whileHover={{ y: -5, transition: { duration: 0.2 } }}>
              <Card className="bg-white shadow-md border-0 h-full overflow-hidden group">
                <CardHeader className="pb-2">
                  <div
                    className={`w-12 h-12 rounded-full bg-${feature.color}-100 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                  >
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
                <CardFooter>
                  <Button
                    variant="ghost"
                    className={`text-${feature.color}-600 p-0 flex items-center gap-1 group-hover:gap-2 transition-all`}
                    onClick={() => handleFeatureClick(feature.route)}
                  >
                    {feature.title === "Chat & kết nối trực tiếp"
                      ? "Kết nối ngay"
                      : feature.title === "Tính năng Premium & đầu tư"
                        ? "Nâng cấp Premium"
                        : "Quét môi trường"}
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 rounded-2xl p-8 text-white text-center relative overflow-hidden"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          {/* Animated background elements */}
          <div className="absolute inset-0 overflow-hidden">
            {isLoaded &&
              Array.from({ length: 10 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute rounded-full bg-white/10"
                  initial={{
                    x: Math.random() * 100 - 50 + "%",
                    y: Math.random() * 100 + "%",
                    scale: Math.random() * 0.5 + 0.5,
                    opacity: Math.random() * 0.5,
                  }}
                  animate={{
                    y: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
                    opacity: [Math.random() * 0.3, Math.random() * 0.5],
                  }}
                  transition={{
                    duration: Math.random() * 20 + 10,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                  }}
                  style={{
                    width: Math.random() * 300 + 50,
                    height: Math.random() * 300 + 50,
                  }}
                />
              ))}
          </div>

          <div className="relative z-10">
            <motion.h2
              className="text-3xl font-bold mb-4"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.0 }}
            >
              Bắt đầu hành trình sáng tạo của bạn
            </motion.h2>
            <motion.p
              className="text-white/80 max-w-2xl mx-auto mb-8"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.2 }}
            >
              Tham gia D WORLD ngay hôm nay để kết nối với cộng đồng sáng tạo, tiếp cận công nghệ mới nhất và biến ý
              tưởng của bạn thành hiện thực.
            </motion.p>
            <motion.div
              className="flex flex-col sm:flex-row gap-4 justify-center"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.4 }}
            >
              <Button
                size="lg"
                className="bg-white text-purple-700 hover:bg-white/90"
                onClick={() => router.push("/register")}
              >
                Đăng ký miễn phí
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="text-white border-white/30 hover:bg-white/10"
                onClick={() => router.push("/about")}
              >
                Tìm hiểu thêm
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-white/10 p-2 rounded-lg">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-bold">D WORLD</h3>
              </div>
              <p className="text-gray-400 mb-4">
                Nền tảng đổi mới sáng tạo toàn diện kết nối ý tưởng, công nghệ và đầu tư.
              </p>
              <div className="flex gap-4">
                <Link href="#" className="text-white/60 hover:text-white transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"></path>
                  </svg>
                </Link>
                <Link href="#" className="text-white/60 hover:text-white transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"></path>
                  </svg>
                </Link>
                <Link href="#" className="text-white/60 hover:text-white transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"></path>
                  </svg>
                </Link>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-medium mb-4">Tính năng</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/features/encyclopedia" className="text-gray-400 hover:text-white transition-colors">
                    Cơ sở dữ liệu bách khoa
                  </Link>
                </li>
                <li>
                  <Link href="/features/ai-research" className="text-gray-400 hover:text-white transition-colors">
                    AI hỗ trợ nghiên cứu
                  </Link>
                </li>
                <li>
                  <Link href="/features/marketplace" className="text-gray-400 hover:text-white transition-colors">
                    Thị trường cung ứng
                  </Link>
                </li>
                <li>
                  <Link href="/features/feasibility" className="text-gray-400 hover:text-white transition-colors">
                    Kiểm tra khả thi
                  </Link>
                </li>
                <li>
                  <Link href="/features/ar-vr" className="text-gray-400 hover:text-white transition-colors">
                    Mô phỏng AR/VR
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-medium mb-4">Hỗ trợ</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/help" className="text-gray-400 hover:text-white transition-colors">
                    Trung tâm trợ giúp
                  </Link>
                </li>
                <li>
                  <Link href="/guide" className="text-gray-400 hover:text-white transition-colors">
                    Hướng dẫn sử dụng
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-gray-400 hover:text-white transition-colors">
                    Câu hỏi thường gặp
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-400 hover:text-white transition-colors">
                    Liên hệ hỗ trợ
                  </Link>
                </li>
                <li>
                  <Link href="/community" className="text-gray-400 hover:text-white transition-colors">
                    Cộng đồng
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-medium mb-4">Pháp lý</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/terms" className="text-gray-400 hover:text-white transition-colors">
                    Điều khoản sử dụng
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-gray-400 hover:text-white transition-colors">
                    Chính sách bảo mật
                  </Link>
                </li>
                <li>
                  <Link href="/ip" className="text-gray-400 hover:text-white transition-colors">
                    Quyền sở hữu trí tuệ
                  </Link>
                </li>
                <li>
                  <Link href="/license" className="text-gray-400 hover:text-white transition-colors">
                    Giấy phép
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400">
            <p>© 2025 D WORLD. Tất cả các quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

