"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, ChevronDown, Filter, Search, ShoppingCart, Star } from "lucide-react"
import Image from "next/image"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"

export default function MarketplacePage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [priceRange, setPriceRange] = useState([0, 10000000])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(value)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: "spring", stiffness: 100 },
    },
  }

  const materials = [
    {
      id: 1,
      name: "Graphene oxide",
      category: "Vật liệu nano",
      price: 1200000,
      unit: "kg",
      rating: 4.8,
      reviews: 124,
      supplier: "TechMat Vietnam",
      image: "/placeholder.svg?height=200&width=300",
      description: "Vật liệu nano tiên tiến với khả năng lọc nước hiệu quả cao, bền và có thể tái sử dụng.",
    },
    {
      id: 2,
      name: "Pin mặt trời CIGS",
      category: "Năng lượng",
      price: 3500000,
      unit: "m²",
      rating: 4.6,
      reviews: 89,
      supplier: "SolarTech Global",
      image: "/placeholder.svg?height=200&width=300",
      description: "Tấm pin mặt trời dẻo công nghệ CIGS với hiệu suất 20%, nhẹ, có thể gập và uốn cong.",
    },
    {
      id: 3,
      name: "Màng lọc nano bạc",
      category: "Vật liệu lọc",
      price: 850000,
      unit: "m²",
      rating: 4.9,
      reviews: 156,
      supplier: "NanoFilter Co.",
      image: "/placeholder.svg?height=200&width=300",
      description: "Màng lọc nano với các hạt bạc kháng khuẩn, lọc được các hạt có kích thước nhỏ đến 0.001 micron.",
    },
    {
      id: 4,
      name: "Sợi carbon composite",
      category: "Vật liệu cấu trúc",
      price: 2800000,
      unit: "kg",
      rating: 4.7,
      reviews: 78,
      supplier: "CompositeTech",
      image: "/placeholder.svg?height=200&width=300",
      description: "Sợi carbon nhẹ, bền, chịu lực tốt, lý tưởng cho các ứng dụng cần độ bền cao và trọng lượng nhẹ.",
    },
    {
      id: 5,
      name: "Vi điều khiển ESP32",
      category: "Điện tử",
      price: 180000,
      unit: "chiếc",
      rating: 4.9,
      reviews: 215,
      supplier: "IoT Solutions",
      image: "/placeholder.svg?height=200&width=300",
      description: "Vi điều khiển ESP32 với WiFi và Bluetooth tích hợp, lý tưởng cho các dự án IoT và tự động hóa.",
    },
    {
      id: 6,
      name: "Nhựa sinh học PLA",
      category: "Vật liệu sinh học",
      price: 450000,
      unit: "kg",
      rating: 4.5,
      reviews: 92,
      supplier: "EcoMaterials",
      image: "/placeholder.svg?height=200&width=300",
      description: "Nhựa sinh học có thể phân hủy, thân thiện với môi trường, phù hợp cho in 3D và sản xuất bao bì.",
    },
  ]

  const equipment = [
    {
      id: 1,
      name: "Máy in 3D Creality Ender-3",
      category: "Thiết bị sản xuất",
      price: 5500000,
      unit: "chiếc",
      rating: 4.7,
      reviews: 183,
      supplier: "3D Print Vietnam",
      image: "/placeholder.svg?height=200&width=300",
      description: "Máy in 3D chất lượng cao với khả năng in vật thể kích thước lên đến 220x220x250mm.",
    },
    {
      id: 2,
      name: "Máy đo laser Bosch GLM 50 C",
      category: "Thiết bị đo lường",
      price: 3200000,
      unit: "chiếc",
      rating: 4.8,
      reviews: 124,
      supplier: "ToolTech",
      image: "/placeholder.svg?height=200&width=300",
      description: "Máy đo khoảng cách laser chính xác đến mm, kết nối Bluetooth với smartphone.",
    },
    {
      id: 3,
      name: "Bộ Arduino Starter Kit",
      category: "Điện tử",
      price: 1200000,
      unit: "bộ",
      rating: 4.9,
      reviews: 256,
      supplier: "RoboticsVN",
      image: "/placeholder.svg?height=200&width=300",
      description: "Bộ kit Arduino đầy đủ với các linh kiện cơ bản để bắt đầu các dự án điện tử.",
    },
  ]

  const services = [
    {
      id: 1,
      name: "Dịch vụ phân tích vật liệu",
      category: "Dịch vụ phòng thí nghiệm",
      price: 5000000,
      unit: "lần",
      rating: 4.8,
      reviews: 67,
      supplier: "LabTech Services",
      image: "/placeholder.svg?height=200&width=300",
      description: "Dịch vụ phân tích thành phần, cấu trúc và tính chất của vật liệu bằng các thiết bị hiện đại.",
    },
    {
      id: 2,
      name: "Tư vấn thiết kế sản phẩm",
      category: "Dịch vụ tư vấn",
      price: 8000000,
      unit: "dự án",
      rating: 4.7,
      reviews: 42,
      supplier: "Design Solutions",
      image: "/placeholder.svg?height=200&width=300",
      description: "Dịch vụ tư vấn thiết kế sản phẩm từ ý tưởng đến bản vẽ kỹ thuật chi tiết.",
    },
    {
      id: 3,
      name: "Gia công CNC chính xác cao",
      category: "Dịch vụ sản xuất",
      price: 2500000,
      unit: "giờ",
      rating: 4.9,
      reviews: 118,
      supplier: "PrecisionTech",
      image: "/placeholder.svg?height=200&width=300",
      description: "Dịch vụ gia công CNC chính xác cao cho các chi tiết kim loại và nhựa kỹ thuật.",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/10"
                onClick={() => router.push("/")}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="bg-white/10 p-2 rounded-lg">
                  <ShoppingCart className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-xl font-bold">Thị trường cung ứng</h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          {/* Search and Filter */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  className="pl-10"
                  placeholder="Tìm kiếm nguyên vật liệu, thiết bị..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all">
                <Search className="mr-2 h-4 w-4" /> Tìm kiếm
              </Button>
            </div>

            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-700 mb-2">Khoảng giá</p>
                <div className="px-2">
                  <Slider
                    defaultValue={priceRange}
                    max={10000000}
                    step={100000}
                    onValueChange={(value) => setPriceRange(value as [number, number])}
                    className="my-4"
                  />
                </div>
                <div className="flex justify-between text-sm text-gray-600">
                  <span>{formatCurrency(priceRange[0])}</span>
                  <span>{formatCurrency(priceRange[1])}</span>
                </div>
              </div>

              <div className="w-px bg-gray-200 hidden md:block"></div>

              <div className="flex-1">
                <p className="text-sm font-medium text-gray-700 mb-2">Danh mục</p>
                <div className="flex flex-wrap gap-2">
                  {["Vật liệu nano", "Năng lượng", "Điện tử", "Vật liệu sinh học", "Thiết bị sản xuất"].map(
                    (category, index) => (
                      <Badge
                        key={index}
                        variant="outline"
                        className="cursor-pointer hover:bg-blue-50 transition-colors"
                      >
                        {category}
                      </Badge>
                    ),
                  )}
                  <Badge variant="outline" className="cursor-pointer hover:bg-blue-50 transition-colors">
                    <ChevronDown className="h-3 w-3 mr-1" /> Xem thêm
                  </Badge>
                </div>
              </div>

              <div className="w-px bg-gray-200 hidden md:block"></div>

              <div className="flex-1">
                <p className="text-sm font-medium text-gray-700 mb-2">Lọc theo</p>
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" className="gap-1">
                    <Filter className="h-3.5 w-3.5" /> Đánh giá cao nhất
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1">
                    <Filter className="h-3.5 w-3.5" /> Bán chạy nhất
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1">
                    <Filter className="h-3.5 w-3.5" /> Mới nhất
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Product Categories */}
          <Tabs defaultValue="materials" className="mb-8">
            <TabsList className="bg-white rounded-lg shadow-sm mb-6">
              <TabsTrigger
                value="materials"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white transition-all duration-300"
              >
                Nguyên vật liệu
              </TabsTrigger>
              <TabsTrigger
                value="equipment"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white transition-all duration-300"
              >
                Thiết bị & Công cụ
              </TabsTrigger>
              <TabsTrigger
                value="services"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white transition-all duration-300"
              >
                Dịch vụ
              </TabsTrigger>
            </TabsList>

            <TabsContent value="materials">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-3 gap-6"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {materials.map((product) => (
                  <motion.div
                    key={product.id}
                    variants={itemVariants}
                    whileHover={{ y: -5, transition: { duration: 0.2 } }}
                    className="cursor-pointer"
                    onClick={() => router.push(`/features/marketplace/product/${product.id}`)}
                  >
                    <Card className="overflow-hidden h-full flex flex-col">
                      <div className="aspect-video relative">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                        <Badge className="absolute top-2 right-2 bg-blue-600">{product.category}</Badge>
                      </div>
                      <CardContent className="p-4 flex-grow">
                        <h3 className="font-medium text-lg mb-1">{product.name}</h3>
                        <p className="text-gray-600 text-sm mb-2 line-clamp-2">{product.description}</p>
                        <div className="flex items-center gap-1 mb-2">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{product.rating}</span>
                          <span className="text-sm text-gray-500">({product.reviews} đánh giá)</span>
                        </div>
                        <p className="text-sm text-gray-500">Nhà cung cấp: {product.supplier}</p>
                      </CardContent>
                      <CardFooter className="p-4 pt-0 flex justify-between items-center border-t">
                        <div>
                          <p className="font-bold text-lg text-blue-700">
                            {formatCurrency(product.price)}/{product.unit}
                          </p>
                        </div>
                        <Button size="sm">Mua ngay</Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            </TabsContent>

            <TabsContent value="equipment">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-3 gap-6"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {equipment.map((product) => (
                  <motion.div
                    key={product.id}
                    variants={itemVariants}
                    whileHover={{ y: -5, transition: { duration: 0.2 } }}
                    className="cursor-pointer"
                    onClick={() => router.push(`/features/marketplace/equipment/${product.id}`)}
                  >
                    <Card className="overflow-hidden h-full flex flex-col">
                      <div className="aspect-video relative">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                        <Badge className="absolute top-2 right-2 bg-purple-600">{product.category}</Badge>
                      </div>
                      <CardContent className="p-4 flex-grow">
                        <h3 className="font-medium text-lg mb-1">{product.name}</h3>
                        <p className="text-gray-600 text-sm mb-2 line-clamp-2">{product.description}</p>
                        <div className="flex items-center gap-1 mb-2">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{product.rating}</span>
                          <span className="text-sm text-gray-500">({product.reviews} đánh giá)</span>
                        </div>
                        <p className="text-sm text-gray-500">Nhà cung cấp: {product.supplier}</p>
                      </CardContent>
                      <CardFooter className="p-4 pt-0 flex justify-between items-center border-t">
                        <div>
                          <p className="font-bold text-lg text-purple-700">
                            {formatCurrency(product.price)}/{product.unit}
                          </p>
                        </div>
                        <Button size="sm">Mua ngay</Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            </TabsContent>

            <TabsContent value="services">
              <motion.div
                className="grid grid-cols-1 md:grid-cols-3 gap-6"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {services.map((product) => (
                  <motion.div
                    key={product.id}
                    variants={itemVariants}
                    whileHover={{ y: -5, transition: { duration: 0.2 } }}
                    className="cursor-pointer"
                    onClick={() => router.push(`/features/marketplace/service/${product.id}`)}
                  >
                    <Card className="overflow-hidden h-full flex flex-col">
                      <div className="aspect-video relative">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                        <Badge className="absolute top-2 right-2 bg-indigo-600">{product.category}</Badge>
                      </div>
                      <CardContent className="p-4 flex-grow">
                        <h3 className="font-medium text-lg mb-1">{product.name}</h3>
                        <p className="text-gray-600 text-sm mb-2 line-clamp-2">{product.description}</p>
                        <div className="flex items-center gap-1 mb-2">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{product.rating}</span>
                          <span className="text-sm text-gray-500">({product.reviews} đánh giá)</span>
                        </div>
                        <p className="text-sm text-gray-500">Nhà cung cấp: {product.supplier}</p>
                      </CardContent>
                      <CardFooter className="p-4 pt-0 flex justify-between items-center border-t">
                        <div>
                          <p className="font-bold text-lg text-indigo-700">
                            {formatCurrency(product.price)}/{product.unit}
                          </p>
                        </div>
                        <Button size="sm">Đặt dịch vụ</Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-center mt-8">
            <Button variant="outline" size="lg" className="gap-2">
              Xem thêm sản phẩm <ChevronDown className="h-4 w-4" />
            </Button>
          </div>
        </motion.div>
      </main>
    </div>
  )
}

