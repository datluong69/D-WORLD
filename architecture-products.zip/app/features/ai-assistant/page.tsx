"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  Brain,
  ChevronRight,
  Lightbulb,
  MessageSquare,
  Paperclip,
  Search,
  Send,
  Settings,
  Sparkles,
  Tag,
  X,
} from "lucide-react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { type Material, type Technology, type Product, materials, technologies, searchDatabase } from "@/lib/database"

// Định nghĩa kiểu dữ liệu cho tin nhắn
type MessageType = {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  attachments?: string[]
  searchResults?: {
    materials: Material[]
    technologies: Technology[]
    products: Product[]
  }
  ideaAnalysis?: {
    title: string
    description: string
    materials: Material[]
    technologies: Technology[]
    estimatedCost: {
      min: number
      max: number
    }
    manufacturingSteps: string[]
    timeEstimate: string
    feasibilityScore: number
  }
}

export default function AIAssistantPage() {
  const router = useRouter()
  const [messages, setMessages] = useState<MessageType[]>([
    {
      id: "1",
      role: "system",
      content:
        "Chào mừng bạn đến với D WORLD AI Assistant. Tôi có thể giúp bạn tìm kiếm thông tin về vật liệu, công nghệ, và sản phẩm, phân tích ý tưởng của bạn, và đề xuất giải pháp chế tạo. Bạn cần hỗ trợ gì?",
      timestamp: new Date(),
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [attachments, setAttachments] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState<string>("chat")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Cuộn xuống tin nhắn mới nhất
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Xử lý gửi tin nhắn
  const handleSendMessage = () => {
    if (!inputMessage.trim() && attachments.length === 0) return

    // Thêm tin nhắn của người dùng
    const userMessage: MessageType = {
      id: Date.now().toString(),
      role: "user",
      content: inputMessage,
      timestamp: new Date(),
      attachments: attachments.length > 0 ? [...attachments] : undefined,
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setAttachments([])
    setIsTyping(true)

    // Xử lý tin nhắn và tạo phản hồi
    setTimeout(() => {
      const response: MessageType = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "",
        timestamp: new Date(),
      }

      // Kiểm tra nếu là tìm kiếm
      if (
        inputMessage.toLowerCase().includes("tìm") ||
        inputMessage.toLowerCase().includes("tra cứu") ||
        inputMessage.toLowerCase().includes("thông tin về")
      ) {
        const searchTerm = inputMessage.replace(/tìm|tra cứu|thông tin về/gi, "").trim()
        const results = searchDatabase(searchTerm)

        response.content = `Tôi đã tìm thấy ${results.totalResults} kết quả liên quan đến "${searchTerm}". Bạn có thể xem chi tiết bên dưới.`
        response.searchResults = {
          materials: results.materials.slice(0, 3),
          technologies: results.technologies.slice(0, 3),
          products: results.products.slice(0, 3),
        }
      }
      // Kiểm tra nếu là phân tích ý tưởng
      else if (
        inputMessage.toLowerCase().includes("ý tưởng") ||
        inputMessage.toLowerCase().includes("chế tạo") ||
        inputMessage.toLowerCase().includes("sản xuất") ||
        inputMessage.toLowerCase().includes("làm")
      ) {
        // Phân tích ý tưởng và tạo phản hồi
        const ideaTitle = inputMessage.length > 30 ? inputMessage.substring(0, 30) + "..." : inputMessage

        // Tìm các vật liệu và công nghệ liên quan
        const relatedMaterials = materials.slice(0, 3)
        const relatedTechnologies = technologies.slice(0, 2)

        response.content = `Tôi đã phân tích ý tưởng của bạn và đây là đề xuất của tôi về cách thực hiện.`
        response.ideaAnalysis = {
          title: ideaTitle,
          description: inputMessage,
          materials: relatedMaterials,
          technologies: relatedTechnologies,
          estimatedCost: {
            min: 5000000,
            max: 15000000,
          },
          manufacturingSteps: [
            "Nghiên cứu và thiết kế chi tiết",
            "Thu thập nguyên vật liệu cần thiết",
            "Chế tạo các thành phần cơ bản",
            "Lắp ráp và tích hợp các thành phần",
            "Kiểm tra và tối ưu hóa",
          ],
          timeEstimate: "3-6 tháng",
          feasibilityScore: 75,
        }
      }
      // Phản hồi thông thường
      else {
        response.content = `Cảm ơn bạn đã chia sẻ. Tôi có thể giúp bạn tìm kiếm thông tin về vật liệu, công nghệ, hoặc phân tích ý tưởng của bạn để đề xuất giải pháp chế tạo. Bạn cần hỗ trợ cụ thể về vấn đề gì?`
      }

      setMessages((prev) => [...prev, response])
      setIsTyping(false)
    }, 1500)
  }

  // Xử lý khi nhấn Enter
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // Xử lý tải lên tệp
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    // Trong thực tế, bạn sẽ tải tệp lên máy chủ
    // Ở đây chúng ta chỉ giả lập bằng cách lưu tên tệp
    const newAttachments = Array.from(files).map((file) => file.name)
    setAttachments((prev) => [...prev, ...newAttachments])
  }

  // Xử lý xóa tệp đính kèm
  const handleRemoveAttachment = (index: number) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index))
  }

  // Format thời gian
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })
  }

  // Format giá tiền
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(value)
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/10"
                onClick={() => router.push("/")}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="bg-white/10 p-2 rounded-lg">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-xl font-bold">D WORLD AI Assistant</h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-grow container mx-auto px-4 py-6 flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <Card className="h-full">
            <CardContent className="p-4">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-2 mb-4">
                  <TabsTrigger value="chat">
                    <MessageSquare className="h-4 w-4 mr-2" /> Chat
                  </TabsTrigger>
                  <TabsTrigger value="search">
                    <Search className="h-4 w-4 mr-2" /> Tra cứu
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="chat" className="mt-0">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium mb-2">Gợi ý</h3>
                      <div className="space-y-2">
                        <Button
                          variant="outline"
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() => setInputMessage("Tìm thông tin về vật liệu graphene oxide")}
                        >
                          <Search className="h-3.5 w-3.5 mr-2 text-blue-600" />
                          Tìm thông tin về graphene oxide
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() =>
                            setInputMessage(
                              "Tôi có ý tưởng chế tạo thiết bị lọc nước di động sử dụng năng lượng mặt trời",
                            )
                          }
                        >
                          <Lightbulb className="h-3.5 w-3.5 mr-2 text-purple-600" />
                          Phân tích ý tưởng thiết bị lọc nước
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() => setInputMessage("Tìm các công nghệ liên quan đến in 3D")}
                        >
                          <Tag className="h-3.5 w-3.5 mr-2 text-indigo-600" />
                          Tìm công nghệ liên quan đến in 3D
                        </Button>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-sm font-medium mb-2">Lịch sử trò chuyện</h3>
                      <div className="space-y-2">
                        <Button variant="ghost" className="w-full justify-start text-sm h-auto py-2 px-3">
                          <MessageSquare className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          <span className="truncate">Tìm kiếm vật liệu mới</span>
                        </Button>
                        <Button variant="ghost" className="w-full justify-start text-sm h-auto py-2 px-3">
                          <MessageSquare className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          <span className="truncate">Phân tích ý tưởng drone</span>
                        </Button>
                        <Button variant="ghost" className="w-full justify-start text-sm h-auto py-2 px-3">
                          <MessageSquare className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          <span className="truncate">Tìm nhà cung cấp</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="search" className="mt-0">
                  <div className="space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input className="pl-9" placeholder="Tìm kiếm..." />
                    </div>

                    <div>
                      <h3 className="text-sm font-medium mb-2">Danh mục</h3>
                      <div className="space-y-1">
                        <Button
                          variant="ghost"
                          className="w-full justify-start text-sm h-auto py-2"
                          onClick={() => router.push("/features/encyclopedia/materials")}
                        >
                          <Tag className="h-3.5 w-3.5 mr-2 text-blue-600" />
                          Vật liệu
                        </Button>
                        <Button
                          variant="ghost"
                          className="w-full justify-start text-sm h-auto py-2"
                          onClick={() => router.push("/features/encyclopedia/technologies")}
                        >
                          <Lightbulb className="h-3.5 w-3.5 mr-2 text-purple-600" />
                          Công nghệ
                        </Button>
                        <Button
                          variant="ghost"
                          className="w-full justify-start text-sm h-auto py-2"
                          onClick={() => router.push("/features/encyclopedia/products")}
                        >
                          <Settings className="h-3.5 w-3.5 mr-2 text-indigo-600" />
                          Sản phẩm
                        </Button>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-sm font-medium mb-2">Tìm kiếm gần đây</h3>
                      <div className="space-y-2">
                        <Button variant="ghost" className="w-full justify-start text-sm h-auto py-2 px-3">
                          <Search className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          <span className="truncate">Graphene oxide</span>
                        </Button>
                        <Button variant="ghost" className="w-full justify-start text-sm h-auto py-2 px-3">
                          <Search className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          <span className="truncate">Công nghệ in 3D</span>
                        </Button>
                        <Button variant="ghost" className="w-full justify-start text-sm h-auto py-2 px-3">
                          <Search className="h-3.5 w-3.5 mr-2 text-gray-500" />
                          <span className="truncate">Thiết bị lọc nước</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <div className="flex-grow flex flex-col bg-white rounded-lg shadow-sm overflow-hidden">
          {/* Messages */}
          <div className="flex-grow overflow-y-auto p-4">
            <div className="space-y-6">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-3xl ${message.role === "user" ? "bg-blue-50 text-gray-800" : message.role === "system" ? "bg-gray-100 text-gray-800" : "bg-white border text-gray-800"} rounded-lg p-4 shadow-sm`}
                  >
                    {message.role !== "user" && (
                      <div className="flex items-center gap-2 mb-2">
                        <div
                          className={`w-8 h-8 rounded-full ${message.role === "system" ? "bg-gray-200" : "bg-purple-100"} flex items-center justify-center`}
                        >
                          <Brain
                            className={`h-4 w-4 ${message.role === "system" ? "text-gray-600" : "text-purple-600"}`}
                          />
                        </div>
                        <div>
                          <p className="font-medium text-sm">{message.role === "system" ? "System" : "D WORLD AI"}</p>
                        </div>
                      </div>
                    )}

                    <div className="prose prose-sm max-w-none">
                      <p>{message.content}</p>

                      {/* Hiển thị tệp đính kèm */}
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="mt-2 space-y-1">
                          <p className="text-sm font-medium">Tệp đính kèm:</p>
                          {message.attachments.map((file, index) => (
                            <div key={index} className="flex items-center gap-2 text-sm text-blue-600">
                              <Paperclip className="h-3.5 w-3.5" />
                              <span>{file}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Hiển thị kết quả tìm kiếm */}
                      {message.searchResults && (
                        <div className="mt-4 space-y-4">
                          {message.searchResults.materials.length > 0 && (
                            <div>
                              <p className="text-sm font-medium flex items-center">
                                <Tag className="h-4 w-4 mr-1 text-blue-600" /> Vật liệu
                              </p>
                              <div className="mt-2 space-y-2">
                                {message.searchResults.materials.map((material) => (
                                  <div
                                    key={material.id}
                                    className="p-2 bg-gray-50 rounded-lg hover:bg-blue-50 cursor-pointer transition-colors"
                                    onClick={() => router.push(`/features/encyclopedia/material/${material.id}`)}
                                  >
                                    <div className="flex justify-between items-start">
                                      <div>
                                        <p className="font-medium text-sm">{material.name}</p>
                                        <p className="text-xs text-gray-600 line-clamp-1">{material.description}</p>
                                      </div>
                                      <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {message.searchResults.technologies.length > 0 && (
                            <div>
                              <p className="text-sm font-medium flex items-center">
                                <Lightbulb className="h-4 w-4 mr-1 text-purple-600" /> Công nghệ
                              </p>
                              <div className="mt-2 space-y-2">
                                {message.searchResults.technologies.map((technology) => (
                                  <div
                                    key={technology.id}
                                    className="p-2 bg-gray-50 rounded-lg hover:bg-purple-50 cursor-pointer transition-colors"
                                    onClick={() => router.push(`/features/encyclopedia/technology/${technology.id}`)}
                                  >
                                    <div className="flex justify-between items-start">
                                      <div>
                                        <p className="font-medium text-sm">{technology.name}</p>
                                        <p className="text-xs text-gray-600 line-clamp-1">{technology.description}</p>
                                      </div>
                                      <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {message.searchResults.products.length > 0 && (
                            <div>
                              <p className="text-sm font-medium flex items-center">
                                <Settings className="h-4 w-4 mr-1 text-indigo-600" /> Sản phẩm
                              </p>
                              <div className="mt-2 space-y-2">
                                {message.searchResults.products.map((product) => (
                                  <div
                                    key={product.id}
                                    className="p-2 bg-gray-50 rounded-lg hover:bg-indigo-50 cursor-pointer transition-colors"
                                    onClick={() => router.push(`/features/encyclopedia/product/${product.id}`)}
                                  >
                                    <div className="flex justify-between items-start">
                                      <div>
                                        <p className="font-medium text-sm">{product.name}</p>
                                        <p className="text-xs text-gray-600 line-clamp-1">{product.description}</p>
                                      </div>
                                      <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-2"
                            onClick={() => router.push("/features/encyclopedia")}
                          >
                            Xem tất cả kết quả
                          </Button>
                        </div>
                      )}

                      {/* Hiển thị phân tích ý tưởng */}
                      {message.ideaAnalysis && (
                        <div className="mt-4 space-y-4">
                          <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-3 rounded-lg">
                            <h3 className="text-sm font-medium flex items-center">
                              <Sparkles className="h-4 w-4 mr-1 text-purple-600" /> Phân tích ý tưởng
                            </h3>
                            <p className="text-xs text-gray-600 mt-1">{message.ideaAnalysis.description}</p>
                          </div>

                          <div>
                            <p className="text-sm font-medium">Vật liệu đề xuất:</p>
                            <div className="mt-2 space-y-2">
                              {message.ideaAnalysis.materials.map((material) => (
                                <div
                                  key={material.id}
                                  className="p-2 bg-gray-50 rounded-lg hover:bg-blue-50 cursor-pointer transition-colors"
                                  onClick={() => router.push(`/features/encyclopedia/material/${material.id}`)}
                                >
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <p className="font-medium text-sm">{material.name}</p>
                                      <p className="text-xs text-gray-600 line-clamp-1">{material.description}</p>
                                    </div>
                                    <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div>
                            <p className="text-sm font-medium">Công nghệ đề xuất:</p>
                            <div className="mt-2 space-y-2">
                              {message.ideaAnalysis.technologies.map((technology) => (
                                <div
                                  key={technology.id}
                                  className="p-2 bg-gray-50 rounded-lg hover:bg-purple-50 cursor-pointer transition-colors"
                                  onClick={() => router.push(`/features/encyclopedia/technology/${technology.id}`)}
                                >
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <p className="font-medium text-sm">{technology.name}</p>
                                      <p className="text-xs text-gray-600 line-clamp-1">{technology.description}</p>
                                    </div>
                                    <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <p className="text-xs font-medium text-gray-600">Chi phí ước tính</p>
                              <p className="font-medium">
                                {formatCurrency(message.ideaAnalysis.estimatedCost.min)} -{" "}
                                {formatCurrency(message.ideaAnalysis.estimatedCost.max)}
                              </p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <p className="text-xs font-medium text-gray-600">Thời gian thực hiện</p>
                              <p className="font-medium">{message.ideaAnalysis.timeEstimate}</p>
                            </div>
                          </div>

                          <div>
                            <p className="text-sm font-medium">Các bước thực hiện:</p>
                            <ol className="mt-2 space-y-1 list-decimal list-inside text-sm">
                              {message.ideaAnalysis.manufacturingSteps.map((step, index) => (
                                <li key={index}>{step}</li>
                              ))}
                            </ol>
                          </div>

                          <div className="p-3 bg-gray-50 rounded-lg">
                            <div className="flex justify-between items-center mb-1">
                              <p className="text-sm font-medium">Tính khả thi</p>
                              <p className="text-sm font-medium">{message.ideaAnalysis.feasibilityScore}%</p>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  message.ideaAnalysis.feasibilityScore > 70
                                    ? "bg-green-600"
                                    : message.ideaAnalysis.feasibilityScore > 40
                                      ? "bg-yellow-500"
                                      : "bg-red-500"
                                }`}
                                style={{ width: `${message.ideaAnalysis.feasibilityScore}%` }}
                              ></div>
                            </div>
                          </div>

                          <div className="flex gap-2">
                            <Button
                              className="bg-gradient-to-r from-blue-600 to-purple-600"
                              onClick={() =>
                                router.push(
                                  `/features/ai-architect?idea=${encodeURIComponent(message.ideaAnalysis.description)}`,
                                )
                              }
                            >
                              Phát triển ý tưởng
                            </Button>
                            <Button variant="outline" onClick={() => router.push("/features/marketplace")}>
                              Tìm nhà cung cấp
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="mt-2 text-right">
                      <span className="text-xs text-gray-500">{formatTime(message.timestamp)}</span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Hiển thị trạng thái đang nhập */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white border rounded-lg p-4 shadow-sm max-w-3xl">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                        <Brain className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">D WORLD AI</p>
                      </div>
                    </div>
                    <div className="mt-2 flex gap-1">
                      <motion.div
                        className="w-2 h-2 bg-gray-400 rounded-full"
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, delay: 0 }}
                      />
                      <motion.div
                        className="w-2 h-2 bg-gray-400 rounded-full"
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, delay: 0.2 }}
                      />
                      <motion.div
                        className="w-2 h-2 bg-gray-400 rounded-full"
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, delay: 0.4 }}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Tham chiếu để cuộn xuống */}
              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* Input Area */}
          <div className="border-t p-4">
            {/* Hiển thị tệp đính kèm */}
            {attachments.length > 0 && (
              <div className="mb-3 flex flex-wrap gap-2">
                {attachments.map((file, index) => (
                  <Badge key={index} className="flex items-center gap-1 bg-blue-100 text-blue-800 hover:bg-blue-200">
                    <Paperclip className="h-3 w-3" />
                    <span className="max-w-[150px] truncate">{file}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 rounded-full p-0 text-blue-800"
                      onClick={() => handleRemoveAttachment(index)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={() => fileInputRef.current?.click()}>
                <Paperclip className="h-5 w-5" />
                <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} multiple />
              </Button>
              <Textarea
                placeholder="Nhập tin nhắn..."
                className="flex-grow resize-none"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
              />
              <Button
                className="bg-gradient-to-r from-blue-600 to-purple-600"
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() && attachments.length === 0}
              >
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

