"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  ChevronRight,
  Info,
  Lightbulb,
  Settings,
  Star,
  Tag,
  ShoppingCart,
  Brain,
  Printer,
  Share,
} from "lucide-react"
import Image from "next/image"
import { useRouter, useParams } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { type Material, type Technology, type Product, materials, getRelatedItems } from "@/lib/database"

export default function MaterialDetailPage() {
  const router = useRouter()
  const params = useParams()
  const [material, setMaterial] = useState<Material | null>(null)
  const [relatedItems, setRelatedItems] = useState<{
    materials: Material[]
    technologies: Technology[]
    products: Product[]
  }>({ materials: [], technologies: [], products: [] })

  useEffect(() => {
    if (params.id) {
      const id = params.id as string
      const foundMaterial = materials.find((m) => m.id === id)

      if (foundMaterial) {
        setMaterial(foundMaterial)
        setRelatedItems(getRelatedItems(id, "material"))
      }
    }
  }, [params.id])

  if (!material) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">Đang tải thông tin...</h2>
          <p className="text-gray-600">Vui lòng đợi trong giây lát</p>
        </div>
      </div>
    )
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(value)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" onClick={() => router.back()}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="bg-white/10 p-2 rounded-lg">
                <Tag className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">{material.name}</h1>
                <p className="text-sm text-white/80">{material.category}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="md:w-1/3">
                      <div className="relative h-60 rounded-lg overflow-hidden">
                        <Image
                          src={material.imageUrl || "/placeholder.svg"}
                          alt={material.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    </div>
                    <div className="md:w-2/3">
                      <h2 className="text-2xl font-bold mb-2">{material.name}</h2>
                      <Badge className="mb-4 bg-blue-100 text-blue-800">{material.category}</Badge>
                      <p className="text-gray-700 mb-4">{material.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {material.applications.slice(0, 3).map((app, index) => (
                          <Badge key={index} variant="outline">
                            {app}
                          </Badge>
                        ))}
                        {material.applications.length > 3 && (
                          <Badge variant="outline">+{material.applications.length - 3}</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Tabs defaultValue="properties">
                <TabsList className="mb-4">
                  <TabsTrigger value="properties">Thuộc tính</TabsTrigger>
                  <TabsTrigger value="applications">Ứng dụng</TabsTrigger>
                  <TabsTrigger value="suppliers">Nhà cung cấp</TabsTrigger>
                </TabsList>

                <TabsContent value="properties">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-lg font-medium mb-4 flex items-center">
                        <Info className="mr-2 h-5 w-5 text-blue-600" /> Thuộc tính vật liệu
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(material.properties).map(([key, value], index) => (
                          <div key={index} className="flex justify-between p-3 bg-gray-50 rounded-lg">
                            <span className="font-medium text-gray-700">{key}</span>
                            <span className="text-gray-900">{value}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="applications">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-lg font-medium mb-4 flex items-center">
                        <Lightbulb className="mr-2 h-5 w-5 text-blue-600" /> Ứng dụng
                      </h3>
                      <div className="space-y-3">
                        {material.applications.map((app, index) => (
                          <div key={index} className="p-3 bg-gray-50 rounded-lg">
                            <p className="text-gray-800">{app}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="suppliers">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-lg font-medium mb-4 flex items-center">
                        <Settings className="mr-2 h-5 w-5 text-blue-600" /> Nhà cung cấp
                      </h3>
                      <div className="space-y-4">
                        {material.suppliers.map((supplier, index) => (
                          <div
                            key={index}
                            className="p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                            onClick={() =>
                              router.push(`/features/marketplace?supplier=${encodeURIComponent(supplier.name)}`)
                            }
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-medium">{supplier.name}</h4>
                                <p className="text-sm text-gray-600">{supplier.location}</p>
                                <div className="flex items-center mt-1">
                                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                                  <span className="text-sm">{supplier.rating}/5.0</span>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-bold text-blue-700">
                                  {formatCurrency(supplier.price)}/{supplier.unit}
                                </p>
                                <Button size="sm" className="mt-2">
                                  Liên hệ
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              {/* Related Materials */}
              {relatedItems.materials.length > 0 && (
                <Card>
                  <CardContent className="p-4">
                    <h3 className="text-lg font-medium mb-3">Vật liệu liên quan</h3>
                    <div className="space-y-3">
                      {relatedItems.materials.map((relatedMaterial) => (
                        <div
                          key={relatedMaterial.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                          onClick={() => router.push(`/features/encyclopedia/material/${relatedMaterial.id}`)}
                        >
                          <div className="relative w-12 h-12 rounded overflow-hidden flex-shrink-0">
                            <Image
                              src={relatedMaterial.imageUrl || "/placeholder.svg"}
                              alt={relatedMaterial.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="flex-grow min-w-0">
                            <h4 className="font-medium text-sm truncate">{relatedMaterial.name}</h4>
                            <p className="text-xs text-gray-600 truncate">{relatedMaterial.category}</p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-gray-400 flex-shrink-0" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              {/* Related Technologies */}
              {relatedItems.technologies.length > 0 && (
                <Card>
                  <CardContent className="p-4">
                    <h3 className="text-lg font-medium mb-3">Công nghệ liên quan</h3>
                    <div className="space-y-3">
                      {relatedItems.technologies.map((technology) => (
                        <div
                          key={technology.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                          onClick={() => router.push(`/features/encyclopedia/technology/${technology.id}`)}
                        >
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                            <Lightbulb className="h-5 w-5 text-purple-600" />
                          </div>
                          <div className="flex-grow min-w-0">
                            <h4 className="font-medium text-sm truncate">{technology.name}</h4>
                            <p className="text-xs text-gray-600 truncate">{technology.category}</p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-gray-400 flex-shrink-0" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              {/* Related Products */}
              {relatedItems.products.length > 0 && (
                <Card>
                  <CardContent className="p-4">
                    <h3 className="text-lg font-medium mb-3">Sản phẩm liên quan</h3>
                    <div className="space-y-3">
                      {relatedItems.products.map((product) => (
                        <div
                          key={product.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                          onClick={() => router.push(`/features/encyclopedia/product/${product.id}`)}
                        >
                          <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0">
                            <Settings className="h-5 w-5 text-indigo-600" />
                          </div>
                          <div className="flex-grow min-w-0">
                            <h4 className="font-medium text-sm truncate">{product.name}</h4>
                            <p className="text-xs text-gray-600 truncate">{product.category}</p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-gray-400 flex-shrink-0" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              {/* Actions */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="text-lg font-medium mb-3">Thao tác</h3>
                  <div className="space-y-2">
                    <Button
                      className="w-full justify-start"
                      onClick={() => router.push(`/features/marketplace?material=${encodeURIComponent(material.name)}`)}
                    >
                      <ShoppingCart className="mr-2 h-4 w-4" /> Tìm kiếm nhà cung cấp
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() =>
                        router.push(`/features/ai-architect?material=${encodeURIComponent(material.name)}`)
                      }
                    >
                      <Brain className="mr-2 h-4 w-4" /> Tạo ý tưởng sản phẩm
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() =>
                        router.push(
                          `/features/encyclopedia/materials?category=${encodeURIComponent(material.category)}`,
                        )
                      }
                    >
                      <Tag className="mr-2 h-4 w-4" /> Xem vật liệu cùng loại
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => window.print()}>
                      <Printer className="mr-2 h-4 w-4" /> In thông tin
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() =>
                        navigator
                          .share({
                            title: material.name,
                            text: material.description,
                            url: window.location.href,
                          })
                          .catch((err) => console.error("Chia sẻ thất bại:", err))
                      }
                    >
                      <Share className="mr-2 h-4 w-4" /> Chia sẻ
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  )
}

