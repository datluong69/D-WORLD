"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Book, ChevronRight, Database, Filter, Lightbulb, Search, Settings, Tag } from "lucide-react"
import Image from "next/image"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  type Material,
  type Technology,
  type Product,
  getCategories,
  getLatestItems,
  searchDatabase,
} from "@/lib/database"

export default function EncyclopediaPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<{
    materials: Material[]
    technologies: Technology[]
    products: Product[]
    totalResults: number
  } | null>(null)
  const [categories, setCategories] = useState<{
    materials: string[]
    technologies: string[]
    products: string[]
  }>({ materials: [], technologies: [], products: [] })
  const [latestItems, setLatestItems] = useState<{
    materials: Material[]
    technologies: Technology[]
    products: Product[]
  }>({ materials: [], technologies: [], products: [] })
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
    setCategories(getCategories())
    setLatestItems(getLatestItems(3))
  }, [])

  const handleSearch = () => {
    if (searchQuery.trim()) {
      const results = searchDatabase(searchQuery)
      setSearchResults(results)
    } else {
      setSearchResults(null)
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: "spring", stiffness: 100 },
    },
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/10"
                onClick={() => router.push("/")}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="bg-white/10 p-2 rounded-lg">
                  <Database className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-xl font-bold">Cơ sở dữ liệu bách khoa toàn thư</h1>
              </div>
            </div>
          </div>

          <div className="mt-12 mb-16 max-w-3xl mx-auto text-center">
            <motion.h2
              className="text-3xl md:text-4xl font-bold mb-4"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Khám phá tri thức về vật liệu, công nghệ và sản phẩm
            </motion.h2>
            <motion.p
              className="text-lg text-white/80 mb-8"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Thư viện dữ liệu toàn diện về nguyên vật liệu, công nghệ và phương pháp chế tạo từ cơ bản đến tiên tiến
            </motion.p>

            <motion.div
              className="relative"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="flex">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    className="w-full py-6 pl-12 pr-4 rounded-l-full text-gray-800 text-lg"
                    placeholder="Tìm kiếm vật liệu, công nghệ hoặc sản phẩm..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  />
                </div>
                <Button
                  className="rounded-r-full bg-gradient-to-r from-blue-600 to-purple-600 py-6 px-8 text-lg"
                  onClick={handleSearch}
                >
                  Tìm kiếm
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 -mt-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          {/* Search Results */}
          {searchResults && (
            <div className="bg-white rounded-xl shadow-md p-6 mb-8">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Kết quả tìm kiếm: {searchResults.totalResults} kết quả</h2>
                <Button variant="outline" size="sm" className="gap-1" onClick={() => setSearchResults(null)}>
                  <Filter className="h-3.5 w-3.5" /> Xóa bộ lọc
                </Button>
              </div>

              <Tabs defaultValue="all" className="mb-8">
                <TabsList className="mb-4">
                  <TabsTrigger value="all">Tất cả ({searchResults.totalResults})</TabsTrigger>
                  <TabsTrigger value="materials">Vật liệu ({searchResults.materials.length})</TabsTrigger>
                  <TabsTrigger value="technologies">Công nghệ ({searchResults.technologies.length})</TabsTrigger>
                  <TabsTrigger value="products">Sản phẩm ({searchResults.products.length})</TabsTrigger>
                </TabsList>

                <TabsContent value="all">
                  <div className="space-y-6">
                    {searchResults.materials.length > 0 && (
                      <div>
                        <h3 className="text-lg font-medium mb-3 flex items-center">
                          <Tag className="mr-2 h-5 w-5 text-blue-600" /> Vật liệu
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {searchResults.materials.slice(0, 3).map((material) => (
                            <Card
                              key={material.id}
                              className="cursor-pointer hover:shadow-md transition-shadow"
                              onClick={() => router.push(`/features/encyclopedia/material/${material.id}`)}
                            >
                              <div className="p-4">
                                <h4 className="font-medium">{material.name}</h4>
                                <p className="text-sm text-gray-600 line-clamp-2 mt-1">{material.description}</p>
                                <Badge className="mt-2 bg-blue-100 text-blue-800 hover:bg-blue-200">
                                  {material.category}
                                </Badge>
                              </div>
                            </Card>
                          ))}
                        </div>
                        {searchResults.materials.length > 3 && (
                          <Button
                            variant="ghost"
                            className="mt-2"
                            onClick={() => router.push(`/features/encyclopedia/materials?q=${searchQuery}`)}
                          >
                            Xem thêm {searchResults.materials.length - 3} vật liệu
                          </Button>
                        )}
                      </div>
                    )}

                    {searchResults.technologies.length > 0 && (
                      <div>
                        <h3 className="text-lg font-medium mb-3 flex items-center">
                          <Lightbulb className="mr-2 h-5 w-5 text-purple-600" /> Công nghệ
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {searchResults.technologies.slice(0, 3).map((technology) => (
                            <Card
                              key={technology.id}
                              className="cursor-pointer hover:shadow-md transition-shadow"
                              onClick={() => router.push(`/features/encyclopedia/technology/${technology.id}`)}
                            >
                              <div className="p-4">
                                <h4 className="font-medium">{technology.name}</h4>
                                <p className="text-sm text-gray-600 line-clamp-2 mt-1">{technology.description}</p>
                                <Badge className="mt-2 bg-purple-100 text-purple-800 hover:bg-purple-200">
                                  {technology.category}
                                </Badge>
                              </div>
                            </Card>
                          ))}
                        </div>
                        {searchResults.technologies.length > 3 && (
                          <Button
                            variant="ghost"
                            className="mt-2"
                            onClick={() => router.push(`/features/encyclopedia/technologies?q=${searchQuery}`)}
                          >
                            Xem thêm {searchResults.technologies.length - 3} công nghệ
                          </Button>
                        )}
                      </div>
                    )}

                    {searchResults.products.length > 0 && (
                      <div>
                        <h3 className="text-lg font-medium mb-3 flex items-center">
                          <Settings className="mr-2 h-5 w-5 text-indigo-600" /> Sản phẩm
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {searchResults.products.slice(0, 3).map((product) => (
                            <Card
                              key={product.id}
                              className="cursor-pointer hover:shadow-md transition-shadow"
                              onClick={() => router.push(`/features/encyclopedia/product/${product.id}`)}
                            >
                              <div className="p-4">
                                <h4 className="font-medium">{product.name}</h4>
                                <p className="text-sm text-gray-600 line-clamp-2 mt-1">{product.description}</p>
                                <Badge className="mt-2 bg-indigo-100 text-indigo-800 hover:bg-indigo-200">
                                  {product.category}
                                </Badge>
                              </div>
                            </Card>
                          ))}
                        </div>
                        {searchResults.products.length > 3 && (
                          <Button
                            variant="ghost"
                            className="mt-2"
                            onClick={() => router.push(`/features/encyclopedia/products?q=${searchQuery}`)}
                          >
                            Xem thêm {searchResults.products.length - 3} sản phẩm
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="materials">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {searchResults.materials.map((material) => (
                      <Card
                        key={material.id}
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => router.push(`/features/encyclopedia/material/${material.id}`)}
                      >
                        <div className="p-4">
                          <h4 className="font-medium">{material.name}</h4>
                          <p className="text-sm text-gray-600 line-clamp-2 mt-1">{material.description}</p>
                          <Badge className="mt-2 bg-blue-100 text-blue-800 hover:bg-blue-200">
                            {material.category}
                          </Badge>
                        </div>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="technologies">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {searchResults.technologies.map((technology) => (
                      <Card
                        key={technology.id}
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => router.push(`/features/encyclopedia/technology/${technology.id}`)}
                      >
                        <div className="p-4">
                          <h4 className="font-medium">{technology.name}</h4>
                          <p className="text-sm text-gray-600 line-clamp-2 mt-1">{technology.description}</p>
                          <Badge className="mt-2 bg-purple-100 text-purple-800 hover:bg-purple-200">
                            {technology.category}
                          </Badge>
                        </div>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="products">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {searchResults.products.map((product) => (
                      <Card
                        key={product.id}
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => router.push(`/features/encyclopedia/product/${product.id}`)}
                      >
                        <div className="p-4">
                          <h4 className="font-medium">{product.name}</h4>
                          <p className="text-sm text-gray-600 line-clamp-2 mt-1">{product.description}</p>
                          <Badge className="mt-2 bg-indigo-100 text-indigo-800 hover:bg-indigo-200">
                            {product.category}
                          </Badge>
                        </div>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}

          {/* Main Content */}
          {!searchResults && (
            <>
              {/* Categories */}
              <div className="bg-white rounded-xl shadow-md p-6 mb-8">
                <h2 className="text-xl font-bold mb-6">Danh mục</h2>

                <Tabs defaultValue="materials">
                  <TabsList className="mb-6">
                    <TabsTrigger
                      value="materials"
                      className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
                    >
                      Vật liệu
                    </TabsTrigger>
                    <TabsTrigger
                      value="technologies"
                      className="data-[state=active]:bg-purple-600 data-[state=active]:text-white"
                    >
                      Công nghệ
                    </TabsTrigger>
                    <TabsTrigger
                      value="products"
                      className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white"
                    >
                      Sản phẩm
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="materials">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {categories.materials.map((category, index) => (
                        <Card
                          key={index}
                          className="cursor-pointer hover:shadow-md transition-shadow hover:bg-blue-50"
                          onClick={() =>
                            router.push(`/features/encyclopedia/materials?category=${encodeURIComponent(category)}`)
                          }
                        >
                          <CardContent className="p-4 flex items-center justify-between">
                            <span className="font-medium">{category}</span>
                            <ChevronRight className="h-5 w-5 text-blue-600" />
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="technologies">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {categories.technologies.map((category, index) => (
                        <Card
                          key={index}
                          className="cursor-pointer hover:shadow-md transition-shadow hover:bg-purple-50"
                          onClick={() =>
                            router.push(`/features/encyclopedia/technologies?category=${encodeURIComponent(category)}`)
                          }
                        >
                          <CardContent className="p-4 flex items-center justify-between">
                            <span className="font-medium">{category}</span>
                            <ChevronRight className="h-5 w-5 text-purple-600" />
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="products">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {categories.products.map((category, index) => (
                        <Card
                          key={index}
                          className="cursor-pointer hover:shadow-md transition-shadow hover:bg-indigo-50"
                          onClick={() =>
                            router.push(`/features/encyclopedia/products?category=${encodeURIComponent(category)}`)
                          }
                        >
                          <CardContent className="p-4 flex items-center justify-between">
                            <span className="font-medium">{category}</span>
                            <ChevronRight className="h-5 w-5 text-indigo-600" />
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              {/* Latest Additions */}
              <div className="mb-8">
                <h2 className="text-xl font-bold mb-6">Thêm mới gần đây</h2>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Latest Materials */}
                  <Card className="overflow-hidden">
                    <div className="bg-blue-600 text-white p-4">
                      <h3 className="text-lg font-medium flex items-center">
                        <Tag className="mr-2 h-5 w-5" /> Vật liệu mới
                      </h3>
                    </div>
                    <CardContent className="p-0">
                      <div className="divide-y">
                        {latestItems.materials.map((material) => (
                          <div
                            key={material.id}
                            className="p-4 hover:bg-blue-50 cursor-pointer transition-colors"
                            onClick={() => router.push(`/features/encyclopedia/material/${material.id}`)}
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-medium">{material.name}</h4>
                                <p className="text-sm text-gray-600 line-clamp-2 mt-1">{material.description}</p>
                                <Badge className="mt-2 bg-blue-100 text-blue-800 hover:bg-blue-200">
                                  {material.category}
                                </Badge>
                              </div>
                              <ChevronRight className="h-5 w-5 text-blue-600 mt-1" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter className="p-4 border-t">
                      <Button
                        variant="ghost"
                        className="w-full text-blue-600"
                        onClick={() => router.push("/features/encyclopedia/materials")}
                      >
                        Xem tất cả vật liệu
                      </Button>
                    </CardFooter>
                  </Card>

                  {/* Latest Technologies */}
                  <Card className="overflow-hidden">
                    <div className="bg-purple-600 text-white p-4">
                      <h3 className="text-lg font-medium flex items-center">
                        <Lightbulb className="mr-2 h-5 w-5" /> Công nghệ mới
                      </h3>
                    </div>
                    <CardContent className="p-0">
                      <div className="divide-y">
                        {latestItems.technologies.map((technology) => (
                          <div
                            key={technology.id}
                            className="p-4 hover:bg-purple-50 cursor-pointer transition-colors"
                            onClick={() => router.push(`/features/encyclopedia/technology/${technology.id}`)}
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-medium">{technology.name}</h4>
                                <p className="text-sm text-gray-600 line-clamp-2 mt-1">{technology.description}</p>
                                <Badge className="mt-2 bg-purple-100 text-purple-800 hover:bg-purple-200">
                                  {technology.category}
                                </Badge>
                              </div>
                              <ChevronRight className="h-5 w-5 text-purple-600 mt-1" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter className="p-4 border-t">
                      <Button
                        variant="ghost"
                        className="w-full text-purple-600"
                        onClick={() => router.push("/features/encyclopedia/technologies")}
                      >
                        Xem tất cả công nghệ
                      </Button>
                    </CardFooter>
                  </Card>

                  {/* Latest Products */}
                  <Card className="overflow-hidden">
                    <div className="bg-indigo-600 text-white p-4">
                      <h3 className="text-lg font-medium flex items-center">
                        <Settings className="mr-2 h-5 w-5" /> Sản phẩm mới
                      </h3>
                    </div>
                    <CardContent className="p-0">
                      <div className="divide-y">
                        {latestItems.products.map((product) => (
                          <div
                            key={product.id}
                            className="p-4 hover:bg-indigo-50 cursor-pointer transition-colors"
                            onClick={() => router.push(`/features/encyclopedia/product/${product.id}`)}
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-medium">{product.name}</h4>
                                <p className="text-sm text-gray-600 line-clamp-2 mt-1">{product.description}</p>
                                <Badge className="mt-2 bg-indigo-100 text-indigo-800 hover:bg-indigo-200">
                                  {product.category}
                                </Badge>
                              </div>
                              <ChevronRight className="h-5 w-5 text-indigo-600 mt-1" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter className="p-4 border-t">
                      <Button
                        variant="ghost"
                        className="w-full text-indigo-600"
                        onClick={() => router.push("/features/encyclopedia/products")}
                      >
                        Xem tất cả sản phẩm
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </div>

              {/* Featured Content */}
              <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 rounded-xl p-6 text-white">
                <div className="flex flex-col md:flex-row items-center gap-6">
                  <div className="md:w-1/2">
                    <h2 className="text-2xl font-bold mb-4">Khám phá thư viện tri thức</h2>
                    <p className="mb-6">
                      Thư viện dữ liệu của chúng tôi chứa thông tin chi tiết về hơn 1,000+ vật liệu, 500+ công nghệ và
                      300+ sản phẩm từ cơ bản đến tiên tiến. Cập nhật liên tục với những phát triển mới nhất trong lĩnh
                      vực khoa học và công nghệ.
                    </p>
                    <Button
                      className="bg-white text-purple-700 hover:bg-white/90"
                      onClick={() => router.push("/features/encyclopedia/about")}
                    >
                      Tìm hiểu thêm <Book className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                  <div className="md:w-1/2 relative h-60 md:h-80 rounded-lg overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=400&width=600&text=Encyclopedia+Library"
                      alt="Thư viện tri thức"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>
            </>
          )}
        </motion.div>
      </main>
    </div>
  )
}

