"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Brain, Lightbulb, Send } from "lucide-react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"

export default function AIArchitectPage() {
  const router = useRouter()
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [response, setResponse] = useState<string | null>(null)
  const [suggestions, setSuggestions] = useState([
    "Thiết bị lọc nước năng lượng mặt trời",
    "Drone giao hàng tự động cho vùng núi",
    "Vật liệu xây dựng từ rác thải nhựa",
    "Hệ thống trồng rau thông minh trong nhà",
  ])

  const handleSubmit = () => {
    if (!prompt.trim()) return

    setIsGenerating(true)

    // Simulate AI response
    setTimeout(() => {
      const responses = {
        "Thiết bị lọc nước năng lượng mặt trời": `
          <h3>Giải pháp công nghệ cho thiết bị lọc nước năng lượng mặt trời:</h3>
          <ul>
            <li><strong>Màng lọc:</strong> Graphene oxide cải tiến (hiệu suất cao, chi phí thấp)</li>
            <li><strong>Năng lượng:</strong> Tấm pin mặt trời dẻo CIGS (hiệu suất 20%, nhẹ, gập được)</li>
            <li><strong>Khử trùng:</strong> Hệ thống UV-LED diệt khuẩn tiết kiệm năng lượng</li>
            <li><strong>Vỏ thiết bị:</strong> Nhựa sinh học phân hủy được, chống tia UV</li>
            <li><strong>Lưu trữ năng lượng:</strong> Pin LiFePO4 (tuổi thọ cao, an toàn)</li>
          </ul>
          <p>Ước tính chi phí sản xuất: 1.200.000 - 1.800.000 VNĐ/thiết bị</p>
          <p>Thời gian phát triển: 6-8 tháng</p>
        `,
        "Drone giao hàng tự động cho vùng núi": `
          <h3>Giải pháp công nghệ cho drone giao hàng vùng núi:</h3>
          <ul>
            <li><strong>Khung drone:</strong> Sợi carbon nhẹ, bền, chịu lực tốt</li>
            <li><strong>Động cơ:</strong> Brushless DC với hiệu suất cao, tiết kiệm năng lượng</li>
            <li><strong>Pin:</strong> LiPo 6S với mật độ năng lượng cao, thời gian bay 45-60 phút</li>
            <li><strong>Định vị:</strong> Hệ thống GPS/GLONASS kép, độ chính xác cao</li>
            <li><strong>Tự động hóa:</strong> AI nhận diện địa hình, tránh chướng ngại vật</li>
            <li><strong>Trọng tải:</strong> 3-5kg hàng hóa</li>
          </ul>
          <p>Ước tính chi phí sản xuất: 15.000.000 - 25.000.000 VNĐ/thiết bị</p>
          <p>Thời gian phát triển: 10-12 tháng</p>
        `,
        "Vật liệu xây dựng từ rác thải nhựa": `
          <h3>Giải pháp công nghệ cho vật liệu xây dựng từ rác thải nhựa:</h3>
          <ul>
            <li><strong>Nguyên liệu:</strong> Nhựa HDPE, PP, PET tái chế</li>
            <li><strong>Công nghệ:</strong> Ép nhiệt kết hợp với phụ gia khoáng</li>
            <li><strong>Cấu trúc:</strong> Lõi rỗng để giảm trọng lượng, tăng cách nhiệt</li>
            <li><strong>Độ bền:</strong> Phụ gia chống UV, chống cháy</li>
            <li><strong>Ứng dụng:</strong> Gạch block, tấm ốp, ngói, thanh dầm nhẹ</li>
          </ul>
          <p>Ước tính chi phí sản xuất: 2.500.000 - 3.500.000 VNĐ/m³</p>
          <p>Thời gian phát triển: 4-6 tháng</p>
        `,
        "Hệ thống trồng rau thông minh trong nhà": `
          <h3>Giải pháp công nghệ cho hệ thống trồng rau thông minh:</h3>
          <ul>
            <li><strong>Phương pháp:</strong> Thủy canh NFT (Nutrient Film Technique)</li>
            <li><strong>Ánh sáng:</strong> Đèn LED quang hợp tiết kiệm năng lượng</li>
            <li><strong>Tự động hóa:</strong> Cảm biến độ ẩm, nhiệt độ, pH, EC</li>
            <li><strong>Điều khiển:</strong> Microcontroller ESP32 kết nối WiFi</li>
            <li><strong>Phần mềm:</strong> App điều khiển từ xa, thông báo, lịch trình</li>
            <li><strong>Năng lượng:</strong> Tích hợp pin mặt trời cho tiết kiệm điện</li>
          </ul>
          <p>Ước tính chi phí sản xuất: 2.000.000 - 4.000.000 VNĐ/bộ</p>
          <p>Thời gian phát triển: 3-5 tháng</p>
        `,
      }

      // Default response for custom prompts
      let generatedResponse = `
        <h3>Giải pháp công nghệ cho ${prompt}:</h3>
        <ul>
          <li><strong>Công nghệ lõi:</strong> AI phân tích dữ liệu thời gian thực</li>
          <li><strong>Vật liệu:</strong> Composite nhẹ, bền, thân thiện môi trường</li>
          <li><strong>Năng lượng:</strong> Pin lithium-ion thế hệ mới, hiệu suất cao</li>
          <li><strong>Kết nối:</strong> IoT tích hợp, giao tiếp 5G</li>
          <li><strong>Giao diện:</strong> AR/VR cho trải nghiệm người dùng</li>
        </ul>
        <p>Ước tính chi phí phát triển: 500.000.000 - 800.000.000 VNĐ</p>
        <p>Thời gian phát triển: 8-12 tháng</p>
      `

      // Check if the prompt matches any of our predefined responses
      for (const key in responses) {
        if (prompt.toLowerCase().includes(key.toLowerCase())) {
          generatedResponse = responses[key as keyof typeof responses]
          break
        }
      }

      setResponse(generatedResponse)
      setIsGenerating(false)
    }, 2000)
  }

  const handleSuggestionClick = (suggestion: string) => {
    setPrompt(suggestion)
    setResponse(null)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/10"
                onClick={() => router.push("/")}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="bg-white/10 p-2 rounded-lg">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-xl font-bold">AI Kiến trúc sư sáng tạo</h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto"
        >
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">Biến ý tưởng của bạn thành giải pháp công nghệ</h2>
            <p className="text-gray-600">
              Mô tả ý tưởng sản phẩm của bạn, AI sẽ đề xuất các giải pháp công nghệ, vật liệu và phương pháp phù hợp
              nhất.
            </p>
          </div>

          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="mb-4">
                <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 mb-2">
                  Mô tả ý tưởng của bạn
                </label>
                <Textarea
                  id="prompt"
                  placeholder="Ví dụ: Tôi muốn chế tạo một thiết bị lọc nước di động sử dụng năng lượng mặt trời..."
                  className="min-h-[120px]"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
              </div>

              <div className="flex justify-between items-center">
                <div className="text-sm text-gray-500">Mô tả càng chi tiết, đề xuất càng chính xác</div>
                <Button
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                  onClick={handleSubmit}
                  disabled={isGenerating || !prompt.trim()}
                >
                  {isGenerating ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                      Đang phân tích...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" /> Phân tích ý tưởng
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="mb-8">
            <h3 className="text-lg font-medium mb-3">Gợi ý ý tưởng</h3>
            <div className="flex flex-wrap gap-2">
              {suggestions.map((suggestion, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="px-3 py-1.5 text-sm cursor-pointer hover:bg-blue-50 transition-colors"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  <Lightbulb className="h-3.5 w-3.5 mr-1.5" />
                  {suggestion}
                </Badge>
              ))}
            </div>
          </div>

          {response && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <Card className="bg-white shadow-md border-0 overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <Brain className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">AI Kiến trúc sư</h3>
                      <p className="text-sm text-gray-500">Phân tích ý tưởng của bạn</p>
                    </div>
                  </div>

                  <div className="prose prose-blue max-w-none" dangerouslySetInnerHTML={{ __html: response }} />

                  <div className="mt-6 flex flex-col sm:flex-row gap-3">
                    <Button
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 transition-all"
                      onClick={() => router.push(`/features/ai-architect/detail?idea=${encodeURIComponent(prompt)}`)}
                    >
                      Xem chi tiết & Hướng dẫn
                    </Button>
                    <Button variant="outline">Lưu kết quả</Button>
                    <Button variant="outline">Tìm nhà cung cấp</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </motion.div>
      </main>
    </div>
  )
}

