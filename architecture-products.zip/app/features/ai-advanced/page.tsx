"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  Brain,
  ChevronRight,
  Database,
  FileText,
  Lightbulb,
  Link2,
  Loader2,
  MessageSquare,
  Paperclip,
  RotateCw,
  Search,
  Send,
  Server,
  Settings,
  Share2,
  Sparkles,
  Tag,
  Upload,
  X,
  Zap,
  ShoppingCart,
} from "lucide-react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { type Material, type Technology, type Product, materials, technologies, searchDatabase } from "@/lib/database"

// Định nghĩa kiểu dữ liệu cho tin nhắn
type MessageType = {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  attachments?: string[]
  searchResults?: {
    materials: Material[]
    technologies: Technology[]
    products: Product[]
    totalResults: number
  }
  ideaAnalysis?: {
    title: string
    description: string
    materials: Material[]
    technologies: Technology[]
    estimatedCost: {
      min: number
      max: number
    }
    manufacturingSteps: string[]
    timeEstimate: string
    feasibilityScore: number
    marketPotential: number
    sustainabilityScore: number
    innovationScore: number
    challenges: string[]
    recommendations: string[]
  }
  marketAnalysis?: {
    targetMarkets: string[]
    competitors: {
      name: string
      strengths: string[]
      weaknesses: string[]
    }[]
    marketSize: string
    growthRate: string
    entryBarriers: string[]
    opportunities: string[]
    threats: string[]
  }
  processingStage?: {
    stage: "analyzing" | "searching" | "generating" | "complete"
    progress: number
    currentTask: string
  }
}

// Định nghĩa kiểu dữ liệu cho nguồn dữ liệu
type DataSource = {
  id: string
  name: string
  type: "database" | "api" | "document"
  description: string
  lastUpdated: Date
  status: "connected" | "disconnected" | "updating"
  itemCount: number
  icon: React.ReactNode
}

// Định nghĩa kiểu dữ liệu cho lịch sử trò chuyện
type ChatHistory = {
  id: string
  title: string
  preview: string
  timestamp: Date
  type: "search" | "idea" | "conversation"
  icon: React.ReactNode
}

export default function AIAdvancedPage() {
  const router = useRouter()
  const [messages, setMessages] = useState<MessageType[]>([
    {
      id: '1',
      role: 'system',
      content: 'Chào mừng bạn đến với D WORLD AI Assistant Pro. Tôi là trợ lý AI tiên tiến được tích hợp với cơ sở dữ liệu toàn diện về vật liệu, công nghệ và sản phẩm. Tôi có thể giúp bạn tìm kiếm thông tin, phân tích ý tưởng, đề xuất giải pháp chế tạo, và phân tích thị trường. Bạn cần hỗ trợ gì?',
      timestamp: new Date(),
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [attachments, setAttachments] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState<string>('chat')
  const [dataSources, setDataSources] = useState<DataSource[]>([
    {
      id: '1',
      name: 'Cơ sở dữ liệu vật liệu',
      type: 'database',
      description: 'Thông tin chi tiết về 10,000+ vật liệu, thuộc tính và ứng dụng',
      lastUpdated: new Date(2025, 2, 15),
      status: 'connected',
      itemCount: 10432,
      icon: <Tag className="h-4 w-4 text-blue-600" />
    },
    {
      id: '2',
      name: 'Cơ sở dữ liệu công nghệ',
      type: 'database',
      description: 'Thông tin về 5,000+ công nghệ sản xuất và chế tạo',
      lastUpdated: new Date(2025, 2, 18),
      status: 'connected',
      itemCount: 5284,
      icon: <Lightbulb className="h-4 w-4 text-purple-600" />
    },
    {
      id: '3',
      name: 'Cơ sở dữ liệu sản phẩm',
      type: 'database',
      description: 'Thông tin về 8,000+ sản phẩm và giải pháp',
      lastUpdated: new Date(2025, 2, 10),
      status: 'connected',
      itemCount: 8156,
      icon: <Settings className="h-4 w-4 text-indigo-600" />
    },
    {
      id: '4',
      name: 'API thị trường toàn cầu',
      type: 'api',
      description: 'Dữ liệu thị trường, giá cả và xu hướng từ các nguồn toàn cầu',
      lastUpdated: new Date(2025, 3, 1),
      status: 'connected',
      itemCount: 0,
      icon: <Server className="h-4 w-4 text-green-600" />
    },
    {
      id: '5',
      name: 'Thư viện tài liệu khoa học',
      type: 'document',
      description: 'Kho lưu trữ 1,000,000+ bài báo khoa học và tài liệu kỹ thuật',
      lastUpdated: new Date(2025, 2, 25),
      status: 'updating',
      itemCount: 1250000,
      icon: <FileText className="h-4 w-4 text-amber-600" />
    }
  ])
  const [chatHistory, setChatHistory] = useState<ChatHistory[]>([
    {
      id: '1',
      title: 'Tìm kiếm vật liệu graphene oxide',
      preview: 'Thông tin chi tiết về vật liệu graphene oxide và ứng dụng',
      timestamp: new Date(2025, 2, 18, 14, 30),
      type: 'search',
      icon: <Search className="h-4 w-4 text-blue-600" />
    },
    {
      id: '2',
      title: 'Phân tích ý tưởng thiết bị lọc nước',
      preview: 'Phân tích ý tưởng thiết bị lọc nước năng lượng mặt trời',
      timestamp: new Date(2025, 2, 17, 10, 15),
      type: 'idea',
      icon: <Lightbulb className="h-4 w-4 text-purple-600" />
    },
    {
      id: '3',
      title: 'Tìm nhà cung cấp pin mặt trời',
      preview: 'Danh sách nhà cung cấp pin mặt trời CIGS tại Việt Nam',
      timestamp: new Date(2025, 2, 15, 9, 45),
      type: 'search',
      icon: <Search className="h-4 w-4 text-blue-600" />
    }
  ])
  const [aiSettings, setAiSettings] = useState({
    responseDetail: 80,
    creativity: 60,
    autoSearch: true,
    autoAnalyze: true,
    dataSourcePriority: {
      database: 90,
      api: 70,
      document: 80
    }
  })
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingStage, setProcessingStage] = useState<MessageType['processingStage']>()
  const [showDataSourceDialog, setShowDataSourceDialog] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Cuộn xuống tin nhắn mới nhất
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Xử lý gửi tin nhắn
  const handleSendMessage = () => {
    if (!inputMessage.trim() && attachments.length === 0) return

    // Thêm tin nhắn của người dùng
    const userMessage: MessageType = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date(),
      attachments: attachments.length > 0 ? [...attachments] : undefined
    }
    
    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setAttachments([])
    setIsTyping(true)
    setIsProcessing(true)

    // Tạo tin nhắn đang xử lý
    const processingMessage: MessageType = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: 'Đang xử lý yêu cầu của bạn...',
      timestamp: new Date(),
      processingStage: {
        stage: 'analyzing',
        progress: 10,
        currentTask: 'Phân tích yêu cầu'
      }
    }
    
    setMessages(prev => [...prev, processingMessage])

    // Mô phỏng quá trình xử lý
    simulateProcessing(processingMessage.id, inputMessage)
  }

  // Mô phỏng quá trình xử lý
  const simulateProcessing = (messageId: string, query: string) => {
    // Xác định loại yêu cầu
    const isSearch = query.toLowerCase().includes('tìm') || 
                     query.toLowerCase().includes('tra cứu') || 
                     query.toLowerCase().includes('thông tin về')
    
    const isIdea = query.toLowerCase().includes('ý tưởng') || 
                   query.toLowerCase().includes('chế tạo') || 
                   query.toLowerCase().includes('sản xuất') ||
                   query.toLowerCase().includes('làm')

    // Mô phỏng phân tích
    setTimeout(() => {
      setMessages(prev => prev.map(msg => 
        msg.id === messageId 
          ? {
              ...msg,
              processingStage: {
                stage: 'analyzing',
                progress: 30,
                currentTask: 'Trích xuất từ khóa và ngữ cảnh'
              }
            }
          : msg
      ))
      
      // Mô phỏng tìm kiếm
      setTimeout(() => {
        setMessages(prev => prev.map(msg => 
          msg.id === messageId 
            ? {
                ...msg,
                processingStage: {
                  stage: 'searching',
                  progress: 50,
                  currentTask: 'Tìm kiếm trong cơ sở dữ liệu'
                }
              }
            : msg
        ))
        
        // Mô phỏng tạo phản hồi
        setTimeout(() => {
          setMessages(prev => prev.map(msg => 
            msg.id === messageId 
              ? {
                  ...msg,
                  processingStage: {
                    stage: 'generating',
                    progress: 80,
                    currentTask: 'Tạo phản hồi chi tiết'
                  }
                }
              : msg
          ))
          
          // Hoàn thành và tạo phản hồi
          setTimeout(() => {
            const response: MessageType = {
              id: messageId,
              role: 'assistant',
              content: '',
              timestamp: new Date(),
              processingStage: {
                stage: 'complete',
                progress: 100,
                currentTask: 'Hoàn thành'
              }
            }

            // Kiểm tra nếu là tìm kiếm
            if (isSearch) {
              const searchTerm = query.replace(/tìm|tra cứu|thông tin về/gi, '').trim()
              const results = searchDatabase(searchTerm)
              
              response.content = `Tôi đã tìm thấy ${results.totalResults} kết quả liên quan đến "${searchTerm}" từ nhiều nguồn dữ liệu. Dưới đây là những kết quả phù hợp nhất.`
              response.searchResults = {
                materials: results.materials.slice(0, 3),
                technologies: results.technologies.slice(0, 3),
                products: results.products.slice(0, 3),
                totalResults: results.totalResults
              }

              // Thêm vào lịch sử
              const newHistory: ChatHistory = {
                id: Date.now().toString(),
                title: `Tìm kiếm: ${searchTerm}`,
                preview: `Kết quả tìm kiếm cho "${searchTerm}"`,
                timestamp: new Date(),
                type: 'search',
                icon: <Search className="h-4 w-4 text-blue-600" />
              }
              setChatHistory(prev => [newHistory, ...prev])
            } 
            // Kiểm tra nếu là phân tích ý tưởng
            else if (isIdea) {
              // Phân tích ý tưởng và tạo phản hồi
              const ideaTitle = query.length > 30 ? 
                query.substring(0, 30) + '...' : 
                query

              // Tìm các vật liệu và công nghệ liên quan
              const relatedMaterials = materials.slice(0, 3)
              const relatedTechnologies = technologies.slice(0, 2)
              
              response.content = `Tôi đã phân tích ý tưởng của bạn một cách toàn diện, kết hợp dữ liệu từ nhiều nguồn khác nhau. Dưới đây là phân tích chi tiết và đề xuất của tôi.`
              response.ideaAnalysis = {
                title: ideaTitle,
                description: query,
                materials: relatedMaterials,
                technologies: relatedTechnologies,
                estimatedCost: {
                  min: 5000000,
                  max: 15000000
                },
                manufacturingSteps: [
                  "Nghiên cứu và thiết kế chi tiết",
                  "Thu thập nguyên vật liệu cần thiết",
                  "Chế tạo các thành phần cơ bản",
                  "Lắp ráp và tích hợp các thành phần",
                  "Kiểm tra và tối ưu hóa",
                  "Đánh giá hiệu suất và điều chỉnh",
                  "Sản xuất thử nghiệm"
                ],
                timeEstimate: "3-6 tháng",
                feasibilityScore: 75,
                marketPotential: 82,
                sustainabilityScore: 88,
                innovationScore: 70,
                challenges: [
                  "Chi phí sản xuất ban đầu cao",
                  "Cần tối ưu hóa hiệu suất năng lượng",
                  "Yêu cầu kỹ thuật chuyên môn cao",
                  "Cạnh tranh từ các sản phẩm hiện có"
                ],
                recommendations: [
                  "Tập trung vào tính bền vững và hiệu quả năng lượng",
                  "Phát triển phiên bản đơn giản hóa để giảm chi phí",
                  "Hợp tác với các chuyên gia trong lĩnh vực",
                  "Đăng ký bảo hộ sở hữu trí tuệ sớm"
                ]
              }

              // Thêm phân tích thị trường
              response.marketAnalysis = {
                targetMarkets: [
                  "Khu vực nông thôn thiếu nước sạch",
                  "Khu vực thường xuyên bị thiên tai",
                  "Thị trường du lịch dã ngoại",
                  "Tổ chức phi chính phủ về môi trường"
                ],
                competitors: [
                  {
                    name: "EcoFilter Inc.",
                    strengths: ["Thương hiệu mạnh", "Mạng lưới phân phối rộng"],
                    weaknesses: ["Giá cao", "Phụ thuộc vào điện lưới"]
                  },
                  {
                    name: "PureWater Tech",
                    strengths: ["Công nghệ tiên tiến", "Hiệu suất cao"],
                    weaknesses: ["Phức tạp khi sử dụng", "Khó bảo trì"]
                  }
                ],
                marketSize: "2.5 tỷ USD (2025)",
                growthRate: "12% hàng năm",
                entryBarriers: [
                  "Yêu cầu chứng nhận chất lượng nước",
                  "Cạnh tranh từ các thương hiệu lớn",
                  "Chi phí R&D cao"
                ],
                opportunities: [
                  "Nhu cầu ngày càng tăng về nước sạch",
                  "Xu hướng sử dụng năng lượng tái tạo",
                  "Hỗ trợ từ chính phủ và tổ chức quốc tế"
                ],
                threats: [
                  "Biến động giá nguyên liệu",
                  "Thay đổi quy định về môi trường",
                  "Công nghệ mới từ đối thủ cạnh tranh"
                ]
              }

              // Thêm vào lịch sử
              const newHistory: ChatHistory = {
                id: Date.now().toString(),
                title: `Phân tích: ${ideaTitle}`,
                preview: `Phân tích chi tiết cho ý tưởng "${ideaTitle}"`,
                timestamp: new Date(),
                type: 'idea',
                icon: <Lightbulb className="h-4 w-4 text-purple-600" />
              }
              setChatHistory(prev => [newHistory, ...prev])
            }
            // Phản hồi thông thường
            else {
              response.content = `Cảm ơn bạn đã chia sẻ. Tôi có thể giúp bạn tìm kiếm thông tin chi tiết về vật liệu, công nghệ, hoặc phân tích toàn diện ý tưởng của bạn để đề xuất giải pháp chế tạo và phân tích thị trường. Bạn cần hỗ trợ cụ thể về vấn đề gì?`
              
              // Thêm vào lịch sử
              const newHistory: ChatHistory = {
                id: Date.now().toString(),
                title: `Cuộc trò chuyện mới`,
                preview: query.substring(0, 50) + (query.length > 50 ? '...' : ''),
                timestamp: new Date(),
                type: 'conversation',
                icon: <MessageSquare className="h-4 w-4 text-gray-600" />
              }
              setChatHistory(prev => [newHistory, ...prev])
            }

            setMessages(prev => prev.map(msg => 
              msg.id === messageId ? response : msg
            ))
            setIsTyping(false)
            setIsProcessing(false)
          }, 1000)
        }, 1500)
      }, 1500)
    }, 1000)
  }

  // Xử lý khi nhấn Enter
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // Xử lý tải lên tệp
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    // Trong thực tế, bạn sẽ tải tệp lên máy chủ
    // Ở đây chúng ta chỉ giả lập bằng cách lưu tên tệp
    const newAttachments = Array.from(files).map(file => file.name)
    setAttachments(prev => [...prev, ...newAttachments])
  }

  // Xử lý xóa tệp đính kèm
  const handleRemoveAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index))
  }

  // Xử lý thay đổi cài đặt AI
  const handleAISettingChange = (setting: string, value: number | boolean) => {
    setAiSettings(prev => ({
      ...prev,
      [setting]: value
    }))
  }

  // Xử lý thay đổi ưu tiên nguồn dữ liệu
  const handleDataSourcePriorityChange = (source: string, value: number) => {
    setAiSettings(prev => ({
      ...prev,
      dataSourcePriority: {
        ...prev.dataSourcePriority,
        [source]: value
      }
    }))
  }

  // Format thời gian
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
  }

  // Format ngày
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' })
  }

  // Format giá tiền
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value)
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-white hover:bg-white/10"
                onClick={() => router.push('/')}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="bg-white/10 p-2 rounded-lg">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">D WORLD AI Assistant Pro</h1>
                  <p className="text-xs text-white/80">Trợ lý AI tiên tiến với thư viện dữ liệu toàn diện</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-white hover:bg-white/10"
                      onClick={() => setShowDataSourceDialog(true)}
                    >
                      <Database className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Quản lý nguồn dữ liệu</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-white hover:bg-white/10"
                        >
                          <Settings className="h-5 w-5" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-80">
                        <div className="space-y-4">
                          <h3 className="font-medium">Cài đặt AI</h3>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <Label htmlFor="responseDetail">Chi tiết phản hồi</Label>
                              <span className="text-sm">{aiSettings.responseDetail}%</span>
                            </div>
                            <Slider 
                              id="responseDetail"
                              min={0} 
                              max={100} 
                              step={10} 
                              defaultValue={[aiSettings.responseDetail]}
                              onValueChange={(value) => handleAISettingChange('responseDetail', value[0])}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <Label htmlFor="creativity">Sáng tạo</Label>
                              <span className="text-sm">{aiSettings.creativity}%</span>
                            </div>
                            <Slider 
                              id="creativity"
                              min={0} 
                              max={100} 
                              step={10} 
                              defaultValue={[aiSettings.creativity]}
                              onValueChange={(value) => handleAISettingChange('creativity', value[0])}
                            />
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <Label htmlFor="autoSearch">Tự động tìm kiếm</Label>
                            <Switch 
                              id="autoSearch" 
                              checked={aiSettings.autoSearch}
                              onCheckedChange={(checked) => handleAISettingChange('autoSearch', checked)}
                            />
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <Label htmlFor="autoAnalyze">Tự động phân tích</Label>
                            <Switch 
                              id="autoAnalyze" 
                              checked={aiSettings.autoAnalyze}
                              onCheckedChange={(checked) => handleAISettingChange('autoAnalyze', checked)}
                            />
                          </div>
                          
                          <Separator />
                          
                          <div>
                            <h4 className="text-sm font-medium mb-2">Ưu tiên nguồn dữ liệu</h4>
                            <div className="space-y-3">
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <Label htmlFor="dbPriority" className="text-xs">Cơ sở dữ liệu</Label>
                                  <span className="text-xs">{aiSettings.dataSourcePriority.database}%</span>
                                </div>
                                <Slider 
                                  id="dbPriority"
                                  min={0} 
                                  max={100} 
                                  step={10} 
                                  defaultValue={[aiSettings.dataSourcePriority.database]}
                                  onValueChange={(value) => handleDataSourcePriorityChange('database', value[0])}
                                />
                              </div>
                              
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <Label htmlFor="apiPriority" className="text-xs">API</Label>
                                  <span className="text-xs">{aiSettings.dataSourcePriority.api}%</span>
                                </div>
                                <Slider 
                                  id="apiPriority"
                                  min={0} 
                                  max={100} 
                                  step={10} 
                                  defaultValue={[aiSettings.dataSourcePriority.api]}
                                  onValueChange={(value) => handleDataSourcePriorityChange('api', value[0])}
                                />
                              </div>
                              
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <Label htmlFor="docPriority" className="text-xs">Tài liệu</Label>
                                  <span className="text-xs">{aiSettings.dataSourcePriority.document}%</span>
                                </div>
                                <Slider 
                                  id="docPriority"
                                  min={0} 
                                  max={100} 
                                  step={10} 
                                  defaultValue={[aiSettings.dataSourcePriority.document]}
                                  onValueChange={(value) => handleDataSourcePriorityChange('document', value[0])}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Cài đặt AI</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-grow container mx-auto px-4 py-6 flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="w-full md:w-72 flex-shrink-0">
          <Card className="h-full">
            <CardContent className="p-4">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-3 mb-4">
                  <TabsTrigger value="chat">
                    <MessageSquare className="h-4 w-4 mr-2" /> Chat
                  </TabsTrigger>
                  <TabsTrigger value="search">
                    <Search className="h-4 w-4 mr-2" /> Tra cứu
                  </TabsTrigger>
                  <TabsTrigger value="history">
                    <RotateCw className="h-4 w-4 mr-2" /> Lịch sử
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="chat" className="mt-0">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium mb-2">Gợi ý</h3>
                      <div className="space-y-2">
                        <Button 
                          variant="outline" 
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() => setInputMessage("Tìm thông tin chi tiết về vật liệu graphene oxide và các ứng dụng mới nhất")}
                        >
                          <Search className="h-3.5 w-3.5 mr-2 text-blue-600" /> 
                          Tìm thông tin về graphene oxide
                        </Button>
                        <Button 
                          variant="outline" 
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() => setInputMessage("Tôi có ý tưởng chế tạo thiết bị lọc nước di động sử dụng năng lượng mặt trời cho vùng nông thôn. Hãy phân tích tính khả thi và đề xuất vật liệu, công nghệ phù hợp.")}
                        >
                          <Lightbulb className="h-3.5 w-3.5 mr-2 text-purple-600" /> 
                          Phân tích ý tưởng thiết bị lọc nước
                        </Button>
                        <Button 
                          variant="outline" 
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() => setInputMessage("Tìm các công nghệ tiên tiến liên quan đến in 3D sinh học và ứng dụng trong y tế")}
                        >
                          <Tag className="h-3.5 w-3.5 mr-2 text-indigo-600" /> 
                          Tìm công nghệ in 3D sinh học
                        </Button>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-sm font-medium mb-2">Tính năng nâng cao</h3>
                      <div className="space-y-2">
                        <Button 
                          variant="outline" 
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() => router.push('/features/ai-architect')}
                        >
                          <Brain className="h-3.5 w-3.5 mr-2 text-purple-600" /> 
                          AI Kiến trúc sư sáng tạo
                        </Button>
                        <Button 
                          variant="outline" 
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() => router.push('/features/marketplace')}
                        >
                          <ShoppingCart className="h-3.5 w-3.5 mr-2 text-blue-600" /> 
                          Thị trường cung ứng
                        </Button>
                        <Button 
                          variant="outline" 
                          className="w-full justify-start text-sm h-auto py-2 px-3"
                          onClick={() => router.push('/features/encyclopedia')}
                        >
                          <Database className="h-3.5 w-3.5 mr-2 text-indigo-600" /> 
                          Cơ sở dữ liệu bách khoa
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="search" className="mt-0">
                  <div className="space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input 
                        className="pl-9" 
                        placeholder="Tìm kiếm..." 
                      />
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium mb-2">Danh mục</h3>
                      <div className="space-y-1">
                        <Button 
                          variant="ghost" 
                          className="w-full justify-start text-sm h-auto py-2"
                          onClick={() => router.push('/features/encyclopedia/materials')}
                        >
                          <Tag className="h-3.5 w-3.5 mr-2 text-blue-600" /> 
                          Vật liệu ({dataSources[0].itemCount.toLocaleString()})
                        </Button>
                        <Button 
                          variant="ghost" 
                          className="w-full justify-start text-sm h-auto py-2"
                          onClick={() => router.push('/features/encyclopedia/technologies')}
                        >
                          <Lightbulb className="h-3.5 w-3.5 mr-2 text-purple-600" /> 
                          Công nghệ ({dataSources[1].itemCount.toLocaleString()})
                        </Button>
                        <Button 
                          variant="ghost" 
                          className="w-full justify-start text-sm h-auto py-2"
                          onClick={() => router.push('/features/encyclopedia/products')}
                        >
                          <Settings className="h-3.5 w-3.5 mr-2 text-indigo-600" /> 
                          Sản phẩm ({dataSources[2].itemCount.toLocaleString()})
                        </Button>
                        <Button 
                          variant="ghost" 
                          className="w-full justify-start text-sm h-auto py-2"
                        >
                          <FileText className="h-3.5 w-3.5 mr-2 text-amber-600" /> 
                          Tài liệu khoa học ({dataSources[4].itemCount.toLocaleString()})
                        </Button>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-sm font-medium mb-2">Tìm kiếm gần đây</h3>
                      <div className="space-y-2">
                        {chatHistory
                          .filter(history => history.type === 'search')
                          .slice(0, 5)
                          .map(history => (
                            <Button 
                              key={history.id}
                              variant="ghost" 
                              className="w-full justify-start text-sm h-auto py-2 px-3"
                            >
                              <Search className="h-3.5 w-3.5 mr-2 text-gray-500" /> 
                              <span className="truncate">{history.title.replace('Tìm kiếm: ', '')}</span>
                            </Button>
                          ))
                        }
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="history" className="mt-0">
                  <div className="space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input 
                        className="pl-9" 
                        placeholder="Tìm trong lịch sử..." 
                      />
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium mb-2">Lịch sử trò chuyện</h3>
                      <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                        {chatHistory.map(history => (
                          <Button 
                            key={history.id}
                            variant="ghost" 
                            className="w-full justify-start text-sm h-auto py-2 px-3"
                          >
                            <div className="flex items-start gap-2 w-full">
                              <div className="mt-0.5">{history.icon}</div>
                              <div className="flex-1 min-w-0 text-left">
                                <p className="font-medium truncate">{history.title}</p>
                                <p className="text-xs text-gray-500 truncate">{history.preview}</p>
                                <p className="text-xs text-gray-400">{formatDate(history.timestamp)}</p>
                              </div>
                            </div>
                          </Button>
                        ))}
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex justify-between">
                      <Button variant="outline" size="sm" className="text-xs">
                        <RotateCw className="h-3 w-3 mr-1" /> Đồng bộ
                      </Button>
                      <Button variant="outline" size="sm" className="text-xs text-red-600 hover:text-red-700">
                        <X className="h-3 w-3 mr-1" /> Xóa lịch sử
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
        
        {/* Chat Area */}
        <div className="flex-grow flex flex-col bg-white rounded-lg shadow-sm overflow-hidden">
          {/* Messages */}
          <div className="flex-grow overflow-y-auto p-4">
            <div className="space-y-6">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-3xl ${message.role === 'user' ? 'bg-blue-50 text-gray-800' : message.role === 'system' ? 'bg-gray-100 text-gray-800' : 'bg-white border text-gray-800'} rounded-lg p-4 shadow-sm`}>
                    {message.role !== 'user' && (
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`w-8 h-8 rounded-full ${message.role === 'system' ? 'bg-gray-200' : 'bg-purple-100'} flex items-center justify-center`}>
                          <Brain className={`h-4 w-4 ${message.role === 'system' ? 'text-gray-600' : 'text-purple-600'}`} />
                        </div>
                        <div>
                          <p className="font-medium text-sm">
                            {message.role === 'system' ? 'System' : 'D WORLD AI Pro'}
                          </p>
                        </div>
                      </div>
                    )}
                    
                    <div className="prose prose-sm max-w-none">
                      {/* Hiển thị trạng thái xử lý */}
                      {message.processingStage && message.processingStage.stage !== 'complete' ? (
                        <div className="space-y-3">
                          <p>{message.content}</p>
                          <div className="space-y-2">
                            <div className="flex justify-between text-xs text-gray-500">
                              <span>{message.processingStage.currentTask}</span>
                              <span>{message.processingStage.progress}%</span>
                            </div>
                            <Progress value={message.processingStage.progress} className="h-1" />
                          </div>
                        </div>
                      ) : (
                        <p>{message.content}</p>
                      )}
                      
                      {/* Hiển thị tệp đính kèm */}
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="mt-2 space-y-1">
                          <p className="text-sm font-medium">Tệp đính kèm:</p>
                          {message.attachments.map((file, index) => (
                            <div key={index} className="flex items-center gap-2 text-sm text-blue-600">
                              <Paperclip className="h-3.5 w-3.5" />
                              <span>{file}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {/* Hiển thị kết quả tìm kiếm */}
                      {message.searchResults && (
                        <div className="mt-4 space-y-4">
                          {message.searchResults.materials.length > 0 && (
                            <div>
                              <p className="text-sm font-medium flex items-center">
                                <Tag className="h-4 w-4 mr-1 text-blue-600" /> Vật liệu
                              </p>
                              <div className="mt-2 space-y-2">
                                {message.searchResults.materials.map((material) => (
                                  <div 
                                    key={material.id}
                                    className="p-2 bg-gray-50 rounded-lg hover:bg-blue-50 cursor-pointer transition-colors"
                                    onClick={() => router.push(`/features/encyclopedia/material/${material.id}`)}
                                  >
                                    <div className="flex justify-between items-start">
                                      <div>
                                        <p className="font-medium text-sm">{material.name}</p>
                                        <p className="text-xs text-gray-600 line-clamp-1">{material.description}</p>
                                        <div className="flex items-center gap-1 mt-1">
                                          <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                                            {material.category}
                                          </Badge>
                                          <span className="text-xs text-gray-500">
                                            {material.suppliers.length} nhà cung cấp
                                          </span>
                                        </div>
                                      </div>
                                      <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {message.searchResults.technologies.length > 0 && (
                            <div>
                              <p className="text-sm font-medium flex items-center">
                                <Lightbulb className="h-4 w-4 mr-1 text-purple-600" /> Công nghệ
                              </p>
                              <div className="mt-2 space-y-2">
                                {message.searchResults.technologies.map((technology) => (
                                  <div 
                                    key={technology.id}
                                    className="p-2 bg-gray-50 rounded-lg hover:bg-purple-50 cursor-pointer transition-colors"
                                    onClick={() => router.push(`/features/encyclopedia/technology/${technology.id}`)}
                                  >
                                    <div className="flex justify-between items-start">
                                      <div>
                                        <p className="font-medium text-sm">{technology.name}</p>
                                        <p className="text-xs text-gray-600 line-clamp-1">{technology.description}</p>
                                        <div className="flex items-center gap-1 mt-1">
                                          <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                                            {technology.category}
                                          </Badge>
                                          <Badge variant="outline" className="text-xs px-1 py-0 h-4 bg-purple-50">
                                            {technology.maturityLevel}
                                          </Badge>
                                        </div>
                                      </div>
                                      <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {message.searchResults.products.length > 0 && (
                            <div>
                              <p className="text-sm font-medium flex items-center">
                                <Settings className="h-4 w-4 mr-1 text-indigo-600" /> Sản phẩm
                              </p>
                              <div className="mt-2 space-y-2">
                                {message.searchResults.products.map((product) => (
                                  <div 
                                    key={product.id}
                                    className="p-2 bg-gray-50 rounded-lg hover:bg-indigo-50 cursor-pointer transition-colors"
                                    onClick={() => router.push(`/features/encyclopedia/product/${product.id}`)}
                                  >
                                    <div className="flex justify-between items-start">
                                      <div>
                                        <p className="font-medium text-sm">{product.name}</p>
                                        <p className="text-xs text-gray-600 line-clamp-1">{product.description}</p>
                                        <div className="flex items-center gap-1 mt-1">
                                          <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                                            {product.category}
                                          </Badge>
                                          <span className="text-xs text-gray-500">
                                            {formatCurrency(product.price)}
                                          </span>
                                        </div>
                                      </div>
                                      <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-xs"
                              onClick={() => router.push('/features/encyclopedia')}
                            >
                              Xem tất cả kết quả ({message.searchResults.totalResults})
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-xs"
                            >
                              <FileText className="h-3 w-3 mr-1" /> Xuất báo cáo
                            </Button>
                          </div>
                        </div>
                      )}
                      
                      {/* Hiển thị phân tích ý tưởng */}
                      {message.ideaAnalysis && (
                        <div className="mt-4 space-y-4">
                          <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-3 rounded-lg">
                            <h3 className="text-sm font-medium flex items-center">
                              <Sparkles className="h-4 w-4 mr-1 text-purple-600" /> Phân tích ý tưởng
                            </h3>
                            <p className="text-xs text-gray-600 mt-1">{message.ideaAnalysis.description}</p>
                          </div>
                          
                          <div>
                            <p className="text-sm font-medium">Vật liệu đề xuất:</p>
                            <div className="mt-2 space-y-2">
                              {message.ideaAnalysis.materials.map((material) => (
                                <div 
                                  key={material.id}
                                  className="p-2 bg-gray-50 rounded-lg hover:bg-blue-50 cursor-pointer transition-colors"
                                  onClick={() => router.push(`/features/encyclopedia/material/${material.id}`)}
                                >
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <p className="font-medium text-sm">{material.name}</p>
                                      <p className="text-xs text-gray-600 line-clamp-1">{material.description}</p>
                                      <div className="flex items-center gap-1 mt-1">
                                        <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                                          {material.category}
                                        </Badge>
                                        <span className="text-xs text-gray-500">
                                          {material.suppliers[0].price.toLocaleString()} VNĐ/{material.suppliers[0].unit}
                                        </span>
                                      </div>
                                    </div>
                                    <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm font-medium">Công nghệ đề xuất:</p>
                            <div className="mt-2 space-y-2">
                              {message.ideaAnalysis.technologies.map((technology) => (
                                <div 
                                  key={technology.id}
                                  className="p-2 bg-gray-50 rounded-lg hover:bg-purple-50 cursor-pointer transition-colors"
                                  onClick={() => router.push(`/features/encyclopedia/technology/${technology.id}`)}
                                >
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <p className="font-medium text-sm">{technology.name}</p>
                                      <p className="text-xs text-gray-600 line-clamp-1">{technology.description}</p>
                                      <div className="flex items-center gap-1 mt-1">
                                        <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                                          {technology.category}
                                        </Badge>
                                        <Badge variant="outline" className="text-xs px-1 py-0 h-4 bg-purple-50">
                                          {technology.maturityLevel}
                                        </Badge>
                                      </div>
                                    </div>
                                    <ChevronRight className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-3">
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <p className="text-xs font-medium text-gray-600">Chi phí ước tính</p>
                              <p className="font-medium">
                                {formatCurrency(message.ideaAnalysis.estimatedCost.min)} - {formatCurrency(message.ideaAnalysis.estimatedCost.max)}
                              </p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <p className="text-xs font-medium text-gray-600">Thời gian thực hiện</p>
                              <p className="font-medium">{message.ideaAnalysis.timeEstimate}</p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-3">
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <div className="flex justify-between items-center mb-1">
                                <p className="text-xs font-medium text-gray-600">Tính khả thi</p>
                                <span className="text-xs font-medium">{message.ideaAnalysis.feasibilityScore}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-1.5">
                                <div 
                                  className={`h-1.5 rounded-full ${
                                    message.ideaAnalysis.feasibilityScore > 70 ? 'bg-green-600' : 
                                    message.ideaAnalysis.feasibilityScore > 40 ? 'bg-yellow-500' : 'bg-red-500'
                                  }`}
                                  style={{ width: `${message.ideaAnalysis.feasibilityScore}%` }}
                                ></div>
                              </div>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <div className="flex justify-between items-center mb-1">
                                <p className="text-xs font-medium text-gray-600">Tiềm năng thị trường</p>
                                <span className="text-xs font-medium">{message.ideaAnalysis.marketPotential}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-1.5">
                                <div 
                                  className={`h-1.5 rounded-full ${
                                    message.ideaAnalysis.marketPotential > 70 ? 'bg-green-600' : 
                                    message.ideaAnalysis.marketPotential > 40 ? 'bg-yellow-500' : 'bg-red-500'
                                  }`}
                                  style={{ width: `${message.ideaAnalysis.marketPotential}%` }}
                                ></div>
                              </div>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <div className="flex justify-between items-center mb-1">
                                <p className="text-xs font-medium text-gray-600">Tính bền vững</p>
                                <span className="text-xs font-medium">{message.ideaAnalysis.sustainabilityScore}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-1.5">
                                <div 
                                  className={`h-1.5 rounded-full ${
                                    message.ideaAnalysis.sustainabilityScore > 70 ? 'bg-green-600' : 
                                    message.ideaAnalysis.sustainabilityScore > 40 ? 'bg-yellow-500' : 'bg-red-500'
                                  }`}
                                  style={{ width: `${message.ideaAnalysis.sustainabilityScore}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm font-medium">Các bước thực hiện:</p>
                            <ol className="mt-2 space-y-1 list-decimal list-inside text-sm">
                              {message.ideaAnalysis.manufacturingSteps.map((step, index) => (
                                <li key={index}>{step}</li>
                              ))}
                            </ol>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium">Thách thức:</p>
                              <ul className="mt-1 space-y-1 list-disc list-inside text-sm">
                                {message.ideaAnalysis.challenges.map((challenge, index) => (
                                  <li key={index} className="text-gray-700">{challenge}</li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Khuyến nghị:</p>
                              <ul className="mt-1 space-y-1 list-disc list-inside text-sm">
                                {message.ideaAnalysis.recommendations.map((recommendation, index) => (
                                  <li key={index} className="text-gray-700">{recommendation}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                          
                          {/* Phân tích thị trường */}
                          {message.marketAnalysis && (
                            <div>
                              <p className="text-sm font-medium flex items-center">
                                <Zap className="h-4 w-4 mr-1 text-amber-600" /> Phân tích thị trường
                              </p>
                              
                              <div className="mt-2 p-3 bg-amber-50 rounded-lg">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-xs font-medium">Thị trường mục tiêu:</p>
                                    <ul className="mt-1 space-y-1 list-disc list-inside text-xs">
                                      {message.marketAnalysis.targetMarkets.map((market, index) => (
                                        <li key={index} className="text-gray-700">{market}</li>
                                      ))}
                                    </ul>
                                  </div>
                                  <div>
                                    <p className="text-xs font-medium">Quy mô thị trường:</p>
                                    <p className="text-xs text-gray-700">{message.marketAnalysis.marketSize}</p>
                                    <p className="text-xs font-medium mt-2">Tốc độ tăng trưởng:</p>
                                    <p className="text-xs text-gray-700">{message.marketAnalysis.growthRate}</p>
                                  </div>
                                </div>
                                
                                <Separator className="my-3" />
                                
                                <div>
                                  <p className="text-xs font-medium">Đối thủ cạnh tranh:</p>
                                  <div className="mt-1 space-y-2">
                                    {message.marketAnalysis.competitors.map((competitor, index) => (
                                      <div key={index} className="text-xs">
                                        <p className="font-medium">{competitor.name}</p>
                                        <div className="grid grid-cols-2 gap-2 mt-1">
                                          <div>
                                            <p className="text-gray-500">Điểm mạnh:</p>
                                            <ul className="list-disc list-inside">
                                              {competitor.strengths.map((strength, idx) => (
                                                <li key={idx} className="text-gray-700">{strength}</li>
                                              ))}
                                            </ul>
                                          </div>
                                          <div>
                                            <p className="text-gray-500">Điểm yếu:</p>
                                            <ul className="list-disc list-inside">
                                              {competitor.weaknesses.map((weakness, idx) => (
                                                <li key={idx} className="text-gray-700">{weakness}</li>
                                              ))}
                                            </ul>
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                                
                                <Separator className="my-3" />
                                
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-xs font-medium">Cơ hội:</p>
                                    <ul className="mt-1 space-y-1 list-disc list-inside text-xs">
                                      {message.marketAnalysis.opportunities.map((opportunity, index) => (
                                        <li key={index} className="text-gray-700">{opportunity}</li>
                                      ))}
                                    </ul>
                                  </div>
                                  <div>
                                    <p className="text-xs font-medium">Thách thức:</p>
                                    <ul className="mt-1 space-y-1 list-disc list-inside text-xs">
                                      {message.marketAnalysis.threats.map((threat, index) => (
                                        <li key={index} className="text-gray-700">{threat}</li>
                                      ))}
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                          
                          <div className="flex flex-wrap gap-2">
                            <Button 
                              className="bg-gradient-to-r from-blue-600 to-purple-600"
                              onClick={() => router.push(`/features/ai-architect?idea=${encodeURIComponent(message.ideaAnalysis.description)}`)}
                            >
                              <Brain className="mr-2 h-4 w-4" /> Phát triển ý tưởng
                            </Button>
                            <Button 
                              variant="outline"
                              onClick={() => router.push('/features/marketplace')}
                            >
                              <ShoppingCart className="mr-2 h-4 w-4" /> Tìm nhà cung cấp
                            </Button>
                            <Button 
                              variant="outline"
                            >
                              <FileText className="mr-2 h-4 w-4" /> Xuất báo cáo
                            </Button>
                            <Button 
                              variant="outline"
                            >
                              <Share2 className="mr-2 h-4 w-4" /> Chia sẻ phân tích
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="mt-2 text-right">
                      <span className="text-xs text-gray-500">{formatTime(message.timestamp)}</span>
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Hiển thị trạng thái đang nhập */}
              {isTyping && !isProcessing && (
                <div className="flex justify-start">
                  <div className="bg-white border rounded-lg p-4 shadow-sm max-w-3xl">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                        <Brain className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">D WORLD AI Pro</p>
                      </div>
                    </div>
                    <div className="mt-2 flex gap-1">
                      <motion.div 
                        className="w-2 h-2 bg-gray-400 rounded-full"
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, delay: 0 }}
                      />
                      <motion.div 
                        className="w-2 h-2 bg-gray-400 rounded-full"
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, delay: 0.2 }}
                      />
                      <motion.div 
                        className="w-2 h-2 bg-gray-400 rounded-full"
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, delay: 0.4 }}
                      />
                    </div>
                  </div>
                </div>
              )}
              
              {/* Tham chiếu để cuộn xuống */}
              <div ref={messagesEndRef} />
            </div>
          </div>
          
          {/* Input Area */}
          <div className="border-t p-4">
            {/* Hiển thị tệp đính kèm */}
            {attachments.length > 0 && (
              <div className="mb-3 flex flex-wrap gap-2">
                {attachments.map((file, index) => (
                  <Badge key={index} className="flex items-center gap-1 bg-blue-100 text-blue-800 hover:bg-blue-200">
                    <Paperclip className="h-3 w-3" />
                    <span className="max-w-[150px] truncate">{file}</span>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-4 w-4 rounded-full p-0 text-blue-800"
                      onClick={() => handleRemoveAttachment(index)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
            
            <div className="flex gap-2">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Paperclip className="h-5 w-5" />
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        className="hidden" 
                        onChange={handleFileUpload}
                        multiple
                      />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Đính kèm tệp</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="icon"
                    >
                      <Upload className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Tải lên tài liệu</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="icon"
                    >
                      <Link2 className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Thêm liên kết</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <Textarea 
                placeholder="Nhập tin nhắn hoặc đặt câu hỏi..." 
                className="flex-grow resize-none"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
              />
              
              <Button 
                className="bg-gradient-to-r from-blue-600 to-purple-600"
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() && attachments.length === 0 || isProcessing}
              >
                {isProcessing ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <Send className="h-5 w-5" />
                )}
              </Button>
            </div>
            
            <div className="mt-2 flex justify-between items-center">
              <div className="text-xs text-gray-500">
                {isProcessing ? (
                  <span className="flex items-center">
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" /> 
                    Đang xử lý...
                  </span>
                ) : (
                  <span>AI được cập nhật đến tháng 3/2025</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  <Database className="h-3 w-3 mr-1" /> 
                  {dataSources.filter(ds => ds.status === 'connected').length}/{dataSources.length} nguồn dữ liệu
                </Badge>
                <Badge variant="outline" className="text-xs bg-purple-50">
                  <Sparkles className="h-3 w-3 mr-1" /> 
                  Pro
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Dialog quản lý nguồn dữ liệu */}
      <Dialog open={showDataSourceDialog} onOpenChange={setShowDataSourceDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Quản lý nguồn dữ liệu</DialogTitle>
            <DialogDescription>
              Quản lý và cấu hình các nguồn dữ liệu được sử dụng bởi AI Assistant Pro.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium">Nguồn dữ liệu đã kết nối</h3>
              <Button size="sm">
                <Database className="h-4 w-4 mr-2" /> Thêm nguồn dữ liệu
              </Button>
            </div>
            
            <div className="space-y-3">
              {dataSources.map((source) => (
                <Card key={source.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mt-1">
                          {source.icon}
                        </div>
                        <div>
                          <h4 className="font-medium">{source.name}</h4>
                          <p className="text-sm text-gray-600">{source.description}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${
                                source.status === 'connected' ? 'bg-green-50 text-green-700' : 
                                source.status === 'updating' ? 'bg-amber-50 text-amber-700' : 
                                'bg-red-50 text-red-700'
                              }`}
                            >
                              {source.status === 'connected' ? 'Đã kết nối' : 
                               source.status === 'updating' ? 'Đang cập nhật' : 'Ngắt kết nối'}
                            </Badge>
                            <span className="text-xs text-gray-500">
                              Cập nhật: {formatDate(source.lastUpdated)}
                            </span>
\

\

