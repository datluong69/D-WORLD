import Image from "next/image"
import { Building2, Compass, Layers, Ruler } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ArchitectureProducts() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Sản Phẩm Kiến Trúc Sáng Tạo</h1>
        <p className="text-muted-foreground max-w-2xl">
          Khám phá bộ sưu tập các sản phẩm kiến trúc sáng tạo của chúng tôi, từ mô hình 3D đến phần mềm thiết kế và vật
          liệu xây dựng đổi mới.
        </p>
      </div>

      <Tabs defaultValue="models" className="w-full max-w-4xl mx-auto">
        <TabsList className="grid grid-cols-4 mb-8">
          <TabsTrigger value="models" className="flex items-center gap-2">
            <Layers className="h-4 w-4" />
            <span className="hidden sm:inline">Mô hình</span>
          </TabsTrigger>
          <TabsTrigger value="software" className="flex items-center gap-2">
            <Compass className="h-4 w-4" />
            <span className="hidden sm:inline">Phần mềm</span>
          </TabsTrigger>
          <TabsTrigger value="materials" className="flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            <span className="hidden sm:inline">Vật liệu</span>
          </TabsTrigger>
          <TabsTrigger value="tools" className="flex items-center gap-2">
            <Ruler className="h-4 w-4" />
            <span className="hidden sm:inline">Công cụ</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="models" className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Mô hình kiến trúc 3D",
                description: "Mô hình chi tiết cao cho các dự án kiến trúc hiện đại",
                image: "/placeholder.svg?height=200&width=300",
                price: "1.200.000 ₫",
              },
              {
                title: "Bộ mô hình đô thị",
                description: "Bộ mô hình quy hoạch đô thị với các thành phần có thể tùy chỉnh",
                image: "/placeholder.svg?height=200&width=300",
                price: "2.500.000 ₫",
              },
              {
                title: "Mô hình nhà ở sinh thái",
                description: "Mô hình kiến trúc xanh với các giải pháp bền vững",
                image: "/placeholder.svg?height=200&width=300",
                price: "1.800.000 ₫",
              },
            ].map((product, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="aspect-video relative">
                  <Image src={product.image || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle>{product.title}</CardTitle>
                  <CardDescription>{product.description}</CardDescription>
                </CardHeader>
                <CardFooter className="flex justify-between">
                  <span className="font-bold">{product.price}</span>
                  <Button size="sm">Xem chi tiết</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
          <div className="flex justify-center">
            <Button variant="outline">Xem thêm sản phẩm</Button>
          </div>
        </TabsContent>

        <TabsContent value="software" className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "ArchiCAD Pro",
                description: "Phần mềm thiết kế kiến trúc chuyên nghiệp với công nghệ BIM",
                image: "/placeholder.svg?height=200&width=300",
                price: "25.000.000 ₫",
              },
              {
                title: "SketchUp Architect",
                description: "Công cụ mô hình hóa 3D trực quan cho kiến trúc sư",
                image: "/placeholder.svg?height=200&width=300",
                price: "12.000.000 ₫",
              },
              {
                title: "Lumion Render Studio",
                description: "Phần mềm render hình ảnh kiến trúc chất lượng cao",
                image: "/placeholder.svg?height=200&width=300",
                price: "18.500.000 ₫",
              },
            ].map((product, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="aspect-video relative">
                  <Image src={product.image || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle>{product.title}</CardTitle>
                  <CardDescription>{product.description}</CardDescription>
                </CardHeader>
                <CardFooter className="flex justify-between">
                  <span className="font-bold">{product.price}</span>
                  <Button size="sm">Xem chi tiết</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="materials" className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Gạch sinh thái",
                description: "Vật liệu xây dựng thân thiện với môi trường",
                image: "/placeholder.svg?height=200&width=300",
                price: "350.000 ₫/m²",
              },
              {
                title: "Kính thông minh",
                description: "Kính điều chỉnh độ trong suốt theo ánh sáng",
                image: "/placeholder.svg?height=200&width=300",
                price: "1.200.000 ₫/m²",
              },
              {
                title: "Tấm ốp tường 3D",
                description: "Tấm ốp tường tạo hiệu ứng không gian ba chiều",
                image: "/placeholder.svg?height=200&width=300",
                price: "450.000 ₫/m²",
              },
            ].map((product, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="aspect-video relative">
                  <Image src={product.image || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle>{product.title}</CardTitle>
                  <CardDescription>{product.description}</CardDescription>
                </CardHeader>
                <CardFooter className="flex justify-between">
                  <span className="font-bold">{product.price}</span>
                  <Button size="sm">Xem chi tiết</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tools" className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Bút vẽ kiến trúc kỹ thuật số",
                description: "Bút vẽ chính xác với cảm biến áp lực",
                image: "/placeholder.svg?height=200&width=300",
                price: "3.500.000 ₫",
              },
              {
                title: "Máy đo laser",
                description: "Thiết bị đo khoảng cách chính xác đến mm",
                image: "/placeholder.svg?height=200&width=300",
                price: "4.200.000 ₫",
              },
              {
                title: "Bộ dụng cụ mô hình hóa",
                description: "Bộ công cụ chuyên nghiệp cho việc tạo mô hình kiến trúc",
                image: "/placeholder.svg?height=200&width=300",
                price: "1.800.000 ₫",
              },
            ].map((product, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="aspect-video relative">
                  <Image src={product.image || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle>{product.title}</CardTitle>
                  <CardDescription>{product.description}</CardDescription>
                </CardHeader>
                <CardFooter className="flex justify-between">
                  <span className="font-bold">{product.price}</span>
                  <Button size="sm">Xem chi tiết</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Bạn cần tư vấn thêm?</h2>
        <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
          Đội ngũ kiến trúc sư chuyên nghiệp của chúng tôi luôn sẵn sàng hỗ trợ bạn lựa chọn sản phẩm phù hợp nhất cho
          dự án của bạn.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg">Liên hệ tư vấn</Button>
          <Button variant="outline" size="lg">
            Xem danh mục đầy đủ
          </Button>
        </div>
      </div>
    </div>
  )
}

