// Cấu trúc dữ liệu cho thư viện bách khoa toàn thư
export type Material = {
  id: string
  name: string
  category: string
  description: string
  properties: {
    [key: string]: string | number
  }
  applications: string[]
  suppliers: {
    name: string
    location: string
    price: number
    unit: string
    rating: number
  }[]
  imageUrl: string
  relatedMaterials: string[]
  createdAt: string
}

export type Technology = {
  id: string
  name: string
  category: string
  description: string
  maturityLevel: string
  advantages: string[]
  limitations: string[]
  applications: string[]
  imageUrl: string
  relatedTechnologies: string[]
  createdAt: string
}

export type Product = {
  id: string
  name: string
  category: string
  description: string
  features: string[]
  specifications: {
    [key: string]: string | number
  }
  price: number
  manufacturer: string
  rating: number
  reviews: number
  imageUrl: string
  relatedProducts: string[]
  createdAt: string
}

// Dữ liệu mẫu cho vật liệu
export const materials: Material[] = [
  {
    id: "graphene-oxide",
    name: "Graphene Oxide",
    category: "Vật liệu nano",
    description:
      "Graphene oxide là một dạng biến thể của graphene, được tạo ra bằng cách oxy hóa graphite. Vật liệu này có độ dẫn điện và nhiệt cao, độ bền cơ học tuyệt vời, và khả năng lọc nước hiệu quả.",
    properties: {
      "Độ dày": "1 nm",
      "Diện tích bề mặt": "2630 m²/g",
      "Độ dẫn nhiệt": "5000 W/mK",
      "Độ bền kéo": "130 GPa",
      "Khả năng lọc": "Lọc được hạt có kích thước đến 0.5 nm",
    },
    applications: [
      "Màng lọc nước hiệu suất cao",
      "Vật liệu composite tăng cường",
      "Pin và siêu tụ điện",
      "Cảm biến sinh học",
      "Vật liệu chống ăn mòn",
    ],
    suppliers: [
      {
        name: "TechMat Vietnam",
        location: "Hà Nội, Việt Nam",
        price: 1200000,
        unit: "kg",
        rating: 4.8,
      },
      {
        name: "NanoMaterials Co.",
        location: "TP. Hồ Chí Minh, Việt Nam",
        price: 1350000,
        unit: "kg",
        rating: 4.6,
      },
      {
        name: "Global Nano Supplies",
        location: "Singapore",
        price: 1500000,
        unit: "kg",
        rating: 4.9,
      },
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Graphene+Oxide",
    relatedMaterials: ["carbon-nanotubes", "reduced-graphene-oxide", "graphene-quantum-dots"],
    createdAt: "2023-05-15",
  },
  {
    id: "cigs-solar-cells",
    name: "Pin mặt trời CIGS",
    category: "Năng lượng",
    description:
      "Pin mặt trời CIGS (Copper Indium Gallium Selenide) là loại pin mặt trời màng mỏng thế hệ mới với hiệu suất cao, có thể uốn cong và nhẹ hơn so với pin silicon truyền thống.",
    properties: {
      "Hiệu suất": "20-22%",
      "Độ dày": "2-3 μm",
      "Trọng lượng": "Nhẹ hơn 95% so với pin silicon",
      "Độ bền": "25+ năm",
      "Khả năng uốn cong": "Bán kính uốn cong tối thiểu 25mm",
    },
    applications: [
      "Hệ thống năng lượng mặt trời di động",
      "Tích hợp vào mái nhà và tường",
      "Thiết bị điện tử cầm tay",
      "Phương tiện giao thông điện",
      "Ứng dụng không gian",
    ],
    suppliers: [
      {
        name: "SolarTech Global",
        location: "Đà Nẵng, Việt Nam",
        price: 3500000,
        unit: "m²",
        rating: 4.7,
      },
      {
        name: "FlexSolar Vietnam",
        location: "Bình Dương, Việt Nam",
        price: 3200000,
        unit: "m²",
        rating: 4.5,
      },
      {
        name: "Advanced Solar Materials",
        location: "Thái Lan",
        price: 3800000,
        unit: "m²",
        rating: 4.8,
      },
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=CIGS+Solar+Cells",
    relatedMaterials: ["perovskite-solar-cells", "thin-film-solar", "flexible-electronics"],
    createdAt: "2023-06-22",
  },
  {
    id: "nano-silver-membrane",
    name: "Màng lọc nano bạc",
    category: "Vật liệu lọc",
    description:
      "Màng lọc nano bạc là vật liệu lọc tiên tiến kết hợp các hạt nano bạc vào cấu trúc màng, mang lại khả năng lọc siêu nhỏ và tính năng kháng khuẩn mạnh mẽ.",
    properties: {
      "Kích thước lỗ lọc": "0.001-0.1 μm",
      "Hiệu suất lọc": ">99.9%",
      "Khả năng kháng khuẩn": "Tiêu diệt >99.9% vi khuẩn và virus",
      "Tuổi thọ": "3-5 năm tùy điều kiện sử dụng",
      "Áp suất hoạt động": "0.1-0.5 MPa",
    },
    applications: [
      "Lọc nước uống",
      "Xử lý nước thải",
      "Thiết bị y tế",
      "Hệ thống lọc không khí",
      "Công nghiệp thực phẩm và đồ uống",
    ],
    suppliers: [
      {
        name: "NanoFilter Co.",
        location: "Hà Nội, Việt Nam",
        price: 850000,
        unit: "m²",
        rating: 4.9,
      },
      {
        name: "PureWater Technologies",
        location: "TP. Hồ Chí Minh, Việt Nam",
        price: 920000,
        unit: "m²",
        rating: 4.7,
      },
      {
        name: "MedicalFilter Asia",
        location: "Malaysia",
        price: 1050000,
        unit: "m²",
        rating: 4.8,
      },
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Nano+Silver+Membrane",
    relatedMaterials: ["ceramic-membranes", "graphene-filters", "antimicrobial-materials"],
    createdAt: "2023-08-10",
  },
  {
    id: "carbon-fiber-composite",
    name: "Sợi carbon composite",
    category: "Vật liệu cấu trúc",
    description:
      "Sợi carbon composite là vật liệu tiên tiến được tạo thành từ sợi carbon được nhúng trong nhựa nền. Vật liệu này có tỷ lệ độ bền trên trọng lượng cực cao, nhẹ hơn nhiều so với thép nhưng bền hơn.",
    properties: {
      "Tỷ trọng": "1.5-2.0 g/cm³",
      "Độ bền kéo": "3500-7000 MPa",
      "Mô-đun đàn hồi": "230-240 GPa",
      "Độ dẫn nhiệt": "21-180 W/mK",
      "Hệ số giãn nở nhiệt": "−0.8 to 0 ×10−6/°C",
    },
    applications: [
      "Khung xe đạp và xe hơi hiệu suất cao",
      "Linh kiện máy bay và vũ trụ",
      "Thiết bị thể thao cao cấp",
      "Cánh tuabin gió",
      "Bộ phận robot và tự động hóa",
    ],
    suppliers: [
      {
        name: "CompositeTech",
        location: "Đồng Nai, Việt Nam",
        price: 2800000,
        unit: "kg",
        rating: 4.7,
      },
      {
        name: "AdvancedMaterials Vietnam",
        location: "Hải Phòng, Việt Nam",
        price: 3100000,
        unit: "kg",
        rating: 4.6,
      },
      {
        name: "AerospaceComposites",
        location: "Nhật Bản",
        price: 3500000,
        unit: "kg",
        rating: 4.9,
      },
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Carbon+Fiber+Composite",
    relatedMaterials: ["kevlar", "fiberglass", "basalt-fiber"],
    createdAt: "2023-04-05",
  },
  {
    id: "biodegradable-pla",
    name: "Nhựa sinh học PLA",
    category: "Vật liệu sinh học",
    description:
      "PLA (Polylactic Acid) là nhựa sinh học được sản xuất từ nguồn tài nguyên tái tạo như bột ngô hoặc mía đường. Vật liệu này có thể phân hủy sinh học hoàn toàn trong điều kiện công nghiệp.",
    properties: {
      "Nhiệt độ nóng chảy": "150-160°C",
      "Độ bền kéo": "50-70 MPa",
      "Thời gian phân hủy": "6-24 tháng (điều kiện công nghiệp)",
      "Tỷ trọng": "1.21-1.43 g/cm³",
      "Độ cứng": "70-90 Shore D",
    },
    applications: [
      "Bao bì thực phẩm thân thiện môi trường",
      "Vật liệu in 3D",
      "Sản phẩm y tế phân hủy sinh học",
      "Đồ dùng một lần thay thế nhựa truyền thống",
      "Vải và sợi sinh học",
    ],
    suppliers: [
      {
        name: "EcoMaterials",
        location: "Cần Thơ, Việt Nam",
        price: 450000,
        unit: "kg",
        rating: 4.5,
      },
      {
        name: "GreenPlastics Vietnam",
        location: "Long An, Việt Nam",
        price: 420000,
        unit: "kg",
        rating: 4.4,
      },
      {
        name: "BioPolymer Asia",
        location: "Indonesia",
        price: 480000,
        unit: "kg",
        rating: 4.7,
      },
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Biodegradable+PLA",
    relatedMaterials: ["pbat", "pba", "pga", "bioplastics"],
    createdAt: "2023-09-18",
  },
  {
    id: "shape-memory-alloy",
    name: "Hợp kim nhớ hình",
    category: "Vật liệu thông minh",
    description:
      "Hợp kim nhớ hình (SMA) là loại vật liệu có khả năng 'nhớ' và quay trở lại hình dạng ban đầu khi được kích hoạt bởi nhiệt độ hoặc từ trường. Phổ biến nhất là hợp kim Nitinol (Ni-Ti).",
    properties: {
      "Nhiệt độ chuyển pha": "-100°C đến +100°C (tùy thành phần)",
      "Độ bền kéo": "895-1900 MPa",
      "Khả năng biến dạng": "Lên đến 8%",
      "Tuổi thọ mỏi": ">10⁷ chu kỳ",
      "Khả năng chống ăn mòn": "Rất tốt",
    },
    applications: [
      "Thiết bị y tế (stent, dây chỉnh nha)",
      "Cơ cấu chấp hành trong robot",
      "Hệ thống giảm chấn động đất",
      "Ăng-ten vệ tinh có thể gập",
      "Khung kính thông minh",
    ],
    suppliers: [
      {
        name: "SmartMaterials Vietnam",
        location: "Hà Nội, Việt Nam",
        price: 5200000,
        unit: "kg",
        rating: 4.8,
      },
      {
        name: "MedicalAlloys",
        location: "TP. Hồ Chí Minh, Việt Nam",
        price: 5500000,
        unit: "kg",
        rating: 4.7,
      },
      {
        name: "AdvancedMetals Asia",
        location: "Hàn Quốc",
        price: 6000000,
        unit: "kg",
        rating: 4.9,
      },
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Shape+Memory+Alloy",
    relatedMaterials: ["nitinol", "smart-materials", "piezoelectric-materials"],
    createdAt: "2023-07-12",
  },
]

// Dữ liệu mẫu cho công nghệ
export const technologies: Technology[] = [
  {
    id: "3d-bioprinting",
    name: "In sinh học 3D",
    category: "Công nghệ y sinh",
    description:
      "In sinh học 3D là công nghệ sử dụng kỹ thuật in 3D để tạo ra các cấu trúc sinh học như mô và cơ quan từ tế bào sống, vật liệu sinh học và các yếu tố tăng trưởng.",
    maturityLevel: "Đang phát triển",
    advantages: [
      "Tạo ra mô và cơ quan tùy chỉnh",
      "Giảm nhu cầu cấy ghép từ người hiến tặng",
      "Giảm khả năng bị đào thải",
      "Hỗ trợ nghiên cứu dược phẩm và thử nghiệm thuốc",
      "Tiềm năng tạo ra các cơ quan hoàn chỉnh",
    ],
    limitations: [
      "Chi phí cao",
      "Hạn chế về kích thước và độ phức tạp",
      "Thách thức trong việc tạo mạch máu",
      "Vấn đề về tuổi thọ của mô",
      "Rào cản pháp lý và đạo đức",
    ],
    applications: [
      "Tạo mô da cho điều trị bỏng",
      "Mô sụn cho phẫu thuật chỉnh hình",
      "Mô gan cho thử nghiệm thuốc",
      "Nghiên cứu bệnh học",
      "Phát triển cơ quan nhân tạo",
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=3D+Bioprinting",
    relatedTechnologies: ["tissue-engineering", "regenerative-medicine", "3d-printing"],
    createdAt: "2023-03-15",
  },
  {
    id: "quantum-computing",
    name: "Máy tính lượng tử",
    category: "Công nghệ thông tin",
    description:
      "Máy tính lượng tử sử dụng các nguyên lý của cơ học lượng tử như chồng chất và vướng víu để thực hiện các phép tính. Thay vì bit nhị phân, máy tính lượng tử sử dụng qubit có thể tồn tại ở nhiều trạng thái cùng một lúc.",
    maturityLevel: "Nghiên cứu và phát triển ban đầu",
    advantages: [
      "Tốc độ tính toán vượt trội cho một số bài toán cụ thể",
      "Khả năng mô phỏng hệ thống lượng tử phức tạp",
      "Tiềm năng phá vỡ các hệ thống mã hóa hiện tại",
      "Tối ưu hóa các bài toán phức tạp",
      "Đột phá trong nghiên cứu vật liệu và dược phẩm",
    ],
    limitations: [
      "Cực kỳ nhạy cảm với nhiễu và mất mát lượng tử",
      "Yêu cầu làm lạnh đến gần 0 Kelvin",
      "Số lượng qubit ổn định còn hạn chế",
      "Chi phí phát triển và vận hành rất cao",
      "Thuật toán lượng tử còn hạn chế",
    ],
    applications: [
      "Mã hóa và bảo mật thông tin",
      "Tối ưu hóa chuỗi cung ứng và hậu cần",
      "Phát triển thuốc và vật liệu mới",
      "Dự báo thời tiết và biến đổi khí hậu",
      "Trí tuệ nhân tạo và học máy",
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Quantum+Computing",
    relatedTechnologies: ["quantum-cryptography", "quantum-sensors", "supercomputing"],
    createdAt: "2023-02-10",
  },
  {
    id: "crispr-gene-editing",
    name: "Chỉnh sửa gen CRISPR",
    category: "Công nghệ sinh học",
    description:
      "CRISPR-Cas9 là công nghệ chỉnh sửa gen cho phép các nhà khoa học thay đổi trình tự DNA một cách chính xác. Công nghệ này hoạt động như một 'kéo phân tử' có thể cắt DNA tại vị trí cụ thể, cho phép thêm, xóa hoặc thay thế các đoạn gen.",
    maturityLevel: "Đang ứng dụng và phát triển",
    advantages: [
      "Chính xác và hiệu quả cao",
      "Chi phí thấp hơn so với các phương pháp chỉnh sửa gen trước đây",
      "Dễ sử dụng và linh hoạt",
      "Có thể chỉnh sửa nhiều gen cùng lúc",
      "Ứng dụng rộng rãi trong nhiều lĩnh vực",
    ],
    limitations: [
      "Khả năng gây ra hiệu ứng ngoài mục tiêu",
      "Thách thức trong việc phân phối đến các tế bào mục tiêu",
      "Vấn đề đạo đức và quy định pháp lý",
      "Hiệu quả chỉnh sửa không đồng đều giữa các loại tế bào",
      "Tiềm năng tác động không lường trước đến hệ sinh thái",
    ],
    applications: [
      "Điều trị bệnh di truyền",
      "Phát triển cây trồng kháng bệnh và chịu hạn",
      "Nghiên cứu cơ bản về chức năng gen",
      "Phát triển liệu pháp ung thư",
      "Kiểm soát véc-tơ truyền bệnh",
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=CRISPR+Gene+Editing",
    relatedTechnologies: ["gene-therapy", "synthetic-biology", "genomics"],
    createdAt: "2023-05-20",
  },
  {
    id: "hydrogen-fuel-cells",
    name: "Pin nhiên liệu hydro",
    category: "Năng lượng",
    description:
      "Pin nhiên liệu hydro là thiết bị điện hóa chuyển đổi năng lượng hóa học của hydro thành điện năng thông qua phản ứng với oxy, với sản phẩm phụ duy nhất là nước và nhiệt.",
    maturityLevel: "Thương mại hóa ban đầu",
    advantages: [
      "Không phát thải khí nhà kính khi sử dụng",
      "Hiệu suất chuyển đổi năng lượng cao (60-80%)",
      "Thời gian nạp nhiên liệu nhanh (3-5 phút)",
      "Phạm vi hoạt động dài (500-700km)",
      "Không bị suy giảm hiệu suất theo thời gian như pin lithium-ion",
    ],
    limitations: [
      "Chi phí sản xuất cao",
      "Hạ tầng nạp nhiên liệu hydro còn hạn chế",
      "Thách thức trong lưu trữ và vận chuyển hydro",
      "Sử dụng kim loại quý như platinum làm chất xúc tác",
      "Sản xuất hydro xanh còn đắt đỏ",
    ],
    applications: [
      "Xe ô tô và xe buýt không phát thải",
      "Phương tiện vận tải hạng nặng",
      "Hệ thống lưu trữ năng lượng quy mô lớn",
      "Cung cấp điện cho các khu vực xa lưới điện",
      "Tàu thủy và đường sắt",
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Hydrogen+Fuel+Cells",
    relatedTechnologies: ["green-hydrogen", "electrolysis", "renewable-energy-storage"],
    createdAt: "2023-06-05",
  },
  {
    id: "augmented-reality",
    name: "Thực tế tăng cường (AR)",
    category: "Công nghệ thông tin",
    description:
      "Thực tế tăng cường (AR) là công nghệ kết hợp nội dung kỹ thuật số với thế giới thực, cho phép người dùng nhìn thấy cả môi trường thực và các đối tượng ảo được chồng lên.",
    maturityLevel: "Đang phát triển và ứng dụng",
    advantages: [
      "Tăng cường trải nghiệm thực tế với thông tin bổ sung",
      "Không yêu cầu tách biệt hoàn toàn khỏi thế giới thực",
      "Có thể sử dụng trên nhiều thiết bị (điện thoại, kính AR)",
      "Ứng dụng rộng rãi trong nhiều ngành công nghiệp",
      "Tương tác trực quan và trực tiếp",
    ],
    limitations: [
      "Hạn chế về phần cứng (pin, xử lý đồ họa)",
      "Thách thức trong việc theo dõi và định vị chính xác",
      "Chi phí phát triển nội dung AR chất lượng cao",
      "Vấn đề quyền riêng tư và bảo mật",
      "Mỏi mắt và khó chịu khi sử dụng lâu",
    ],
    applications: [
      "Đào tạo và hướng dẫn công nghiệp",
      "Thiết kế và kiến trúc",
      "Y tế và phẫu thuật",
      "Giáo dục và học tập tương tác",
      "Bán lẻ và thương mại điện tử",
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Augmented+Reality",
    relatedTechnologies: ["virtual-reality", "mixed-reality", "spatial-computing"],
    createdAt: "2023-04-12",
  },
  {
    id: "vertical-farming",
    name: "Nông nghiệp theo chiều dọc",
    category: "Nông nghiệp",
    description:
      "Nông nghiệp theo chiều dọc là phương pháp canh tác trong nhà, nhiều tầng, sử dụng công nghệ kiểm soát môi trường để tối ưu hóa sự phát triển của cây trồng mà không phụ thuộc vào điều kiện tự nhiên.",
    maturityLevel: "Đang ứng dụng thương mại",
    advantages: [
      "Sử dụng đất hiệu quả (sản lượng cao trên diện tích nhỏ)",
      "Tiết kiệm nước (sử dụng ít hơn 95% so với canh tác truyền thống)",
      "Không phụ thuộc vào thời tiết và mùa vụ",
      "Giảm sử dụng thuốc trừ sâu và phân bón",
      "Gần với thị trường tiêu thụ, giảm chi phí vận chuyển",
    ],
    limitations: [
      "Chi phí đầu tư ban đầu cao",
      "Tiêu thụ nhiều năng lượng",
      "Hạn chế về loại cây trồng (chủ yếu rau xanh và thảo mộc)",
      "Yêu cầu kỹ thuật và quản lý phức tạp",
      "Thách thức trong việc mở rộng quy mô",
    ],
    applications: [
      "Sản xuất rau xanh trong đô thị",
      "Cung cấp thực phẩm cho khu vực khan hiếm đất canh tác",
      "Nghiên cứu nông nghiệp và phát triển giống cây",
      "Mô hình canh tác trong không gian hạn chế",
      "Sản xuất dược liệu có giá trị cao",
    ],
    imageUrl: "/placeholder.svg?height=400&width=600&text=Vertical+Farming",
    relatedTechnologies: ["hydroponics", "aeroponics", "controlled-environment-agriculture"],
    createdAt: "2023-08-18",
  },
]

// Dữ liệu mẫu cho sản phẩm
export const products: Product[] = [
  {
    id: "portable-water-filter",
    name: "Thiết bị lọc nước di động năng lượng mặt trời",
    category: "Thiết bị môi trường",
    description:
      "Thiết bị lọc nước di động sử dụng năng lượng mặt trời, tích hợp màng lọc graphene oxide và hệ thống khử trùng UV-LED, phù hợp cho các vùng sâu vùng xa thiếu nước sạch và điện lưới.",
    features: [
      "Lọc nước từ nhiều nguồn (sông, hồ, nước mưa, nước ngầm)",
      "Công suất lọc: 15-20 lít/giờ",
      "Màng lọc graphene oxide loại bỏ 99.9% vi khuẩn, kim loại nặng và chất ô nhiễm",
      "Hệ thống khử trùng UV-LED tiêu diệt vi khuẩn và virus",
      "Pin mặt trời CIGS hiệu suất cao, có thể gập gọn",
    ],
    specifications: {
      "Kích thước": "30 x 20 x 15 cm (gập gọn)",
      "Trọng lượng": "2.5 kg",
      "Công suất pin": "15W",
      "Dung lượng pin dự phòng": "10,000 mAh",
      "Tuổi thọ màng lọc": "1,500 lít hoặc 6 tháng",
      "Chỉ số lọc": "0.001 micron",
    },
    price: 3500000,
    manufacturer: "CleanTech Vietnam",
    rating: 4.8,
    reviews: 156,
    imageUrl: "/placeholder.svg?height=400&width=600&text=Portable+Water+Filter",
    relatedProducts: ["solar-power-bank", "backpack-water-purifier", "emergency-water-filter"],
    createdAt: "2023-07-15",
  },
  {
    id: "drone-delivery-system",
    name: "Drone giao hàng tự động cho vùng núi",
    category: "Thiết bị vận chuyển",
    description:
      "Hệ thống drone giao hàng tự động được thiết kế đặc biệt cho địa hình vùng núi khó tiếp cận, tích hợp AI nhận diện địa hình và hệ thống định vị chính xác cao.",
    features: [
      "Khung drone bằng sợi carbon siêu nhẹ, bền",
      "Hệ thống AI tránh chướng ngại vật và nhận diện địa hình",
      "Định vị GPS/GLONASS kép với độ chính xác đến 10cm",
      "Thời gian bay liên tục 45-60 phút",
      "Khả năng chịu gió cấp 6, hoạt động trong điều kiện thời tiết khắc nghiệt",
    ],
    specifications: {
      "Kích thước": "80 x 80 x 30 cm",
      "Trọng lượng": "3.5 kg (không tải)",
      "Tải trọng tối đa": "5 kg",
      "Phạm vi hoạt động": "30 km",
      "Tốc độ tối đa": "70 km/h",
      Pin: "LiPo 6S 22000mAh",
      "Thời gian sạc": "90 phút",
    },
    price: 25000000,
    manufacturer: "VietDrone Technologies",
    rating: 4.7,
    reviews: 42,
    imageUrl: "/placeholder.svg?height=400&width=600&text=Mountain+Delivery+Drone",
    relatedProducts: ["cargo-drone", "medical-delivery-drone", "agricultural-drone"],
    createdAt: "2023-05-10",
  },
  {
    id: "smart-hydroponic-system",
    name: "Hệ thống trồng rau thủy canh thông minh",
    category: "Nông nghiệp công nghệ cao",
    description:
      "Hệ thống trồng rau thủy canh thông minh tự động hóa hoàn toàn quá trình canh tác, tích hợp IoT và AI để tối ưu hóa điều kiện phát triển của cây trồng.",
    features: [
      "Hệ thống NFT (Nutrient Film Technique) tiết kiệm nước và dinh dưỡng",
      "Đèn LED quang hợp tiết kiệm năng lượng, tối ưu cho từng loại cây",
      "Cảm biến độ ẩm, nhiệt độ, pH, EC tự động điều chỉnh",
      "Điều khiển từ xa qua smartphone với thông báo thời gian thực",
      "Tích hợp pin mặt trời giảm tiêu thụ điện lưới",
    ],
    specifications: {
      "Kích thước": "120 x 60 x 180 cm",
      "Công suất": "36 vị trí trồng cây",
      "Tiêu thụ nước": "90% ít hơn canh tác truyền thống",
      "Tiêu thụ điện": "60W (đèn LED) + 15W (bơm và điều khiển)",
      "Kết nối": "WiFi, Bluetooth",
      "Ứng dụng hỗ trợ": "iOS, Android",
    },
    price: 4500000,
    manufacturer: "SmartFarm Vietnam",
    rating: 4.9,
    reviews: 87,
    imageUrl: "/placeholder.svg?height=400&width=600&text=Smart+Hydroponic+System",
    relatedProducts: ["vertical-garden", "smart-greenhouse", "aquaponic-system"],
    createdAt: "2023-09-05",
  },
  {
    id: "recycled-plastic-building-blocks",
    name: "Gạch xây dựng từ rác thải nhựa tái chế",
    category: "Vật liệu xây dựng",
    description:
      "Gạch xây dựng được sản xuất từ rác thải nhựa tái chế, có cấu trúc lõi rỗng giúp cách nhiệt tốt, nhẹ hơn gạch truyền thống nhưng vẫn đảm bảo độ bền và khả năng chịu lực.",
    features: [
      "Sử dụng 95% nhựa tái chế (chủ yếu HDPE, PP, PET)",
      "Cấu trúc lõi rỗng tăng khả năng cách nhiệt và giảm trọng lượng",
      "Khả năng chống thấm nước và ẩm mốc",
      "Phụ gia chống UV và chống cháy",
      "Dễ dàng lắp ghép, giảm thời gian xây dựng",
    ],
    specifications: {
      "Kích thước tiêu chuẩn": "25 x 12.5 x 10 cm",
      "Trọng lượng": "1.2 kg/viên (nhẹ hơn 40% so với gạch truyền thống)",
      "Khả năng chịu lực": "15-20 MPa",
      "Độ hấp thụ nước": "<0.5%",
      "Độ bền": ">50 năm",
      "Khả năng cách nhiệt": "R-value 2.5 (cao hơn 40% so với gạch thông thường)",
    },
    price: 12000,
    manufacturer: "GreenBuild Vietnam",
    rating: 4.6,
    reviews: 124,
    imageUrl: "/placeholder.svg?height=400&width=600&text=Recycled+Plastic+Bricks",
    relatedProducts: ["eco-roof-tiles", "recycled-composite-panels", "sustainable-flooring"],
    createdAt: "2023-03-20",
  },
  {
    id: "ai-environmental-analyzer",
    name: "Thiết bị phân tích môi trường AI",
    category: "Thiết bị môi trường",
    description:
      "Thiết bị cầm tay sử dụng AI và cảm biến tiên tiến để phân tích chất lượng không khí, nước và đất, cung cấp kết quả chi tiết và đề xuất giải pháp trong thời gian thực.",
    features: [
      "Cảm biến đa thông số cho không khí, nước và đất",
      "AI phân tích và so sánh với cơ sở dữ liệu toàn cầu",
      "Kết quả chi tiết trong vòng 60 giây",
      "Đề xuất giải pháp dựa trên kết quả phân tích",
      "Chia sẻ dữ liệu với cộng đồng và chuyên gia",
    ],
    specifications: {
      "Kích thước": "15 x 8 x 3 cm",
      "Trọng lượng": "350g",
      Pin: "5000mAh, sử dụng liên tục 8 giờ",
      "Kết nối": "WiFi, Bluetooth, 4G",
      "Thông số đo không khí": "PM2.5, PM10, VOCs, CO2, O3, nhiệt độ, độ ẩm",
      "Thông số đo nước": "pH, độ đục, TDS, kim loại nặng, vi khuẩn",
      "Thông số đo đất": "pH, NPK, độ ẩm, kim loại nặng, vi sinh vật",
    },
    price: 8500000,
    manufacturer: "EcoSense Technologies",
    rating: 4.8,
    reviews: 76,
    imageUrl: "/placeholder.svg?height=400&width=600&text=AI+Environmental+Analyzer",
    relatedProducts: ["water-quality-tester", "soil-analyzer", "air-quality-monitor"],
    createdAt: "2023-08-12",
  },
  {
    id: "solar-desalination-unit",
    name: "Thiết bị khử mặn nước biển bằng năng lượng mặt trời",
    category: "Thiết bị môi trường",
    description:
      "Hệ thống khử mặn nước biển quy mô nhỏ hoạt động hoàn toàn bằng năng lượng mặt trời, sử dụng công nghệ màng lọc tiên tiến và cô đặc nhiệt mặt trời để tạo ra nước ngọt từ nước biển.",
    features: [
      "Hoạt động 100% bằng năng lượng mặt trời",
      "Kết hợp công nghệ màng lọc và cô đặc nhiệt",
      "Không cần thay thế màng lọc thường xuyên",
      "Tự động làm sạch và bảo dưỡng",
      "Thiết kế mô-đun, dễ dàng mở rộng công suất",
    ],
    specifications: {
      "Kích thước": "120 x 80 x 50 cm (đơn vị cơ bản)",
      "Công suất": "50-100 lít nước ngọt/ngày (tùy điều kiện nắng)",
      "Diện tích tấm thu nhiệt": "2m²",
      "Công suất pin mặt trời": "200W",
      "Hiệu suất chuyển đổi": "30-40% (cao hơn 3 lần so với phương pháp truyền thống)",
      "Độ tinh khiết nước": "TDS <50 ppm (đạt tiêu chuẩn nước uống)",
    },
    price: 15000000,
    manufacturer: "SolarWater Solutions",
    rating: 4.7,
    reviews: 38,
    imageUrl: "/placeholder.svg?height=400&width=600&text=Solar+Desalination+Unit",
    relatedProducts: ["portable-water-filter", "rainwater-harvesting-system", "water-purification-tablets"],
    createdAt: "2023-06-25",
  },
]

// Hàm tìm kiếm trong cơ sở dữ liệu
export function searchDatabase(query: string) {
  const normalizedQuery = query.toLowerCase().trim()

  // Tìm kiếm trong vật liệu
  const matchedMaterials = materials.filter(
    (material) =>
      material.name.toLowerCase().includes(normalizedQuery) ||
      material.description.toLowerCase().includes(normalizedQuery) ||
      material.category.toLowerCase().includes(normalizedQuery) ||
      material.applications.some((app) => app.toLowerCase().includes(normalizedQuery)),
  )

  // Tìm kiếm trong công nghệ
  const matchedTechnologies = technologies.filter(
    (tech) =>
      tech.name.toLowerCase().includes(normalizedQuery) ||
      tech.description.toLowerCase().includes(normalizedQuery) ||
      tech.category.toLowerCase().includes(normalizedQuery) ||
      tech.applications.some((app) => app.toLowerCase().includes(normalizedQuery)) ||
      tech.advantages.some((adv) => adv.toLowerCase().includes(normalizedQuery)),
  )

  // Tìm kiếm trong sản phẩm
  const matchedProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(normalizedQuery) ||
      product.description.toLowerCase().includes(normalizedQuery) ||
      product.category.toLowerCase().includes(normalizedQuery) ||
      product.features.some((feature) => feature.toLowerCase().includes(normalizedQuery)),
  )

  return {
    materials: matchedMaterials,
    technologies: matchedTechnologies,
    products: matchedProducts,
    totalResults: matchedMaterials.length + matchedTechnologies.length + matchedProducts.length,
  }
}

// Hàm lấy các mục liên quan
export function getRelatedItems(id: string, type: "material" | "technology" | "product") {
  const relatedItems = {
    materials: [] as Material[],
    technologies: [] as Technology[],
    products: [] as Product[],
  }

  if (type === "material") {
    const material = materials.find((m) => m.id === id)
    if (material) {
      // Lấy các vật liệu liên quan
      relatedItems.materials = materials.filter((m) => material.relatedMaterials.includes(m.id) && m.id !== id)

      // Lấy các công nghệ liên quan (dựa trên category)
      relatedItems.technologies = technologies
        .filter(
          (t) =>
            t.category.toLowerCase().includes(material.category.toLowerCase()) ||
            t.applications.some((app) =>
              material.applications.some((mApp) => mApp.toLowerCase().includes(app.toLowerCase())),
            ),
        )
        .slice(0, 3)

      // Lấy các sản phẩm liên quan
      relatedItems.products = products
        .filter(
          (p) =>
            p.description.toLowerCase().includes(material.name.toLowerCase()) ||
            p.features.some((f) => f.toLowerCase().includes(material.name.toLowerCase())),
        )
        .slice(0, 3)
    }
  } else if (type === "technology") {
    const technology = technologies.find((t) => t.id === id)
    if (technology) {
      // Lấy các công nghệ liên quan
      relatedItems.technologies = technologies.filter(
        (t) => technology.relatedTechnologies.includes(t.id) && t.id !== id,
      )

      // Lấy các vật liệu liên quan
      relatedItems.materials = materials
        .filter((m) =>
          m.applications.some((app) =>
            technology.applications.some((tApp) => tApp.toLowerCase().includes(app.toLowerCase())),
          ),
        )
        .slice(0, 3)

      // Lấy các sản phẩm liên quan
      relatedItems.products = products
        .filter(
          (p) =>
            p.description.toLowerCase().includes(technology.name.toLowerCase()) ||
            p.features.some((f) => f.toLowerCase().includes(technology.name.toLowerCase())),
        )
        .slice(0, 3)
    }
  } else if (type === "product") {
    const product = products.find((p) => p.id === id)
    if (product) {
      // Lấy các sản phẩm liên quan
      relatedItems.products = products.filter((p) => product.relatedProducts.includes(p.id) && p.id !== id)

      // Lấy các vật liệu liên quan
      relatedItems.materials = materials
        .filter(
          (m) =>
            product.description.toLowerCase().includes(m.name.toLowerCase()) ||
            product.features.some((f) => f.toLowerCase().includes(m.name.toLowerCase())),
        )
        .slice(0, 3)

      // Lấy các công nghệ liên quan
      relatedItems.technologies = technologies
        .filter(
          (t) =>
            product.description.toLowerCase().includes(t.name.toLowerCase()) ||
            product.features.some((f) => f.toLowerCase().includes(t.name.toLowerCase())),
        )
        .slice(0, 3)
    }
  }

  return relatedItems
}

// Hàm lấy các danh mục
export function getCategories() {
  const materialCategories = [...new Set(materials.map((m) => m.category))]
  const technologyCategories = [...new Set(technologies.map((t) => t.category))]
  const productCategories = [...new Set(products.map((p) => p.category))]

  return {
    materials: materialCategories,
    technologies: technologyCategories,
    products: productCategories,
  }
}

// Hàm lấy các mục mới nhất
export function getLatestItems(limit = 5) {
  const sortedMaterials = [...materials]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit)

  const sortedTechnologies = [...technologies]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit)

  const sortedProducts = [...products]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit)

  return {
    materials: sortedMaterials,
    technologies: sortedTechnologies,
    products: sortedProducts,
  }
}

