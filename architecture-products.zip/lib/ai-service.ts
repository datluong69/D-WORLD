import { type Material, type Technology, searchDatabase } from "@/lib/database"

// Định nghĩa kiểu dữ liệu cho phân tích ý tưởng
export type IdeaAnalysis = {
  title: string
  description: string
  materials: Material[]
  technologies: Technology[]
  estimatedCost: {
    min: number
    max: number
  }
  manufacturingSteps: string[]
  timeEstimate: string
  feasibilityScore: number
}

// Hàm phân tích ý tưởng
export async function analyzeIdea(idea: string): Promise<IdeaAnalysis> {
  // Trong thực tế, đây sẽ là một API call đến một mô hình AI
  // Ở đây chúng ta giả lập phân tích

  // Tìm các từ khóa trong ý tưởng
  const keywords = extractKeywords(idea)

  // Tìm các vật liệu và công nghệ liên quan
  const relatedMaterials: Material[] = []
  const relatedTechnologies: Technology[] = []

  // Tìm kiếm vật liệu và công nghệ dựa trên từ khóa
  for (const keyword of keywords) {
    const results = searchDatabase(keyword)

    // Thêm vật liệu không trùng lặp
    for (const material of results.materials) {
      if (!relatedMaterials.some((m) => m.id === material.id)) {
        relatedMaterials.push(material)
        if (relatedMaterials.length >= 3) break
      }
    }

    // Thêm công nghệ không trùng lặp
    for (const technology of results.technologies) {
      if (!relatedTechnologies.some((t) => t.id === technology.id)) {
        relatedTechnologies.push(technology)
        if (relatedTechnologies.length >= 2) break
      }
    }

    // Dừng nếu đã có đủ vật liệu và công nghệ
    if (relatedMaterials.length >= 3 && relatedTechnologies.length >= 2) break
  }

  // Tính toán chi phí ước tính
  const estimatedCost = calculateEstimatedCost(relatedMaterials, relatedTechnologies)

  // Tính toán điểm khả thi
  const feasibilityScore = calculateFeasibilityScore(idea, relatedMaterials, relatedTechnologies)

  // Tạo các bước thực hiện
  const manufacturingSteps = generateManufacturingSteps(idea)

  // Ước tính thời gian
  const timeEstimate = estimateTime(idea, manufacturingSteps.length)

  return {
    title: idea.length > 30 ? idea.substring(0, 30) + "..." : idea,
    description: idea,
    materials: relatedMaterials,
    technologies: relatedTechnologies,
    estimatedCost,
    manufacturingSteps,
    timeEstimate,
    feasibilityScore,
  }
}

// Hàm trích xuất từ khóa từ ý tưởng
function extractKeywords(idea: string): string[] {
  // Trong thực tế, đây sẽ sử dụng NLP để trích xuất từ khóa
  // Ở đây chúng ta giả lập bằng cách tách các từ và lọc
  const words = idea.toLowerCase().split(/\s+/)
  const stopWords = ["và", "hoặc", "là", "của", "cho", "với", "trong", "một", "các", "những"]

  return words.filter((word) => word.length > 3 && !stopWords.includes(word)).slice(0, 5) // Lấy tối đa 5 từ khóa
}

// Hàm tính toán chi phí ước tính
function calculateEstimatedCost(materials: Material[], technologies: Technology[]): { min: number; max: number } {
  // Trong thực tế, đây sẽ là một thuật toán phức tạp hơn
  // Ở đây chúng ta giả lập một cách đơn giản

  let baseCost = 2000000 // Chi phí cơ bản

  // Cộng thêm chi phí vật liệu
  for (const material of materials) {
    // Lấy giá trung bình từ các nhà cung cấp
    const avgPrice = material.suppliers.reduce((sum, supplier) => sum + supplier.price, 0) / material.suppliers.length
    baseCost += avgPrice
  }

  // Cộng thêm chi phí công nghệ (giả định)
  baseCost += technologies.length * 1000000

  // Thêm biên độ dao động
  return {
    min: Math.round(baseCost * 0.8),
    max: Math.round(baseCost * 1.5),
  }
}

// Hàm tính toán điểm khả thi
function calculateFeasibilityScore(idea: string, materials: Material[], technologies: Technology[]): number {
  // Trong thực tế, đây sẽ là một thuật toán phức tạp hơn
  // Ở đây chúng ta giả lập một cách đơn giản

  let score = 50 // Điểm cơ bản

  // Cộng điểm nếu có đủ vật liệu
  score += materials.length * 5

  // Cộng điểm nếu có đủ công nghệ
  score += technologies.length * 7

  // Trừ điểm nếu ý tưởng quá phức tạp
  if (idea.length > 200) score -= 10

  // Giới hạn điểm trong khoảng 0-100
  return Math.max(0, Math.min(100, score))
}

// Hàm tạo các bước thực hiện
function generateManufacturingSteps(idea: string): string[] {
  // Trong thực tế, đây sẽ được tạo bởi AI dựa trên ý tưởng
  // Ở đây chúng ta trả về các bước cơ bản

  return [
    "Nghiên cứu và thiết kế chi tiết",
    "Thu thập nguyên vật liệu cần thiết",
    "Chế tạo các thành phần cơ bản",
    "Lắp ráp và tích hợp các thành phần",
    "Kiểm tra và tối ưu hóa",
  ]
}

// Hàm ước tính thời gian
function estimateTime(idea: string, steps: number): string {
  // Trong thực tế, đây sẽ là một thuật toán phức tạp hơn
  // Ở đây chúng ta giả lập một cách đơn giản

  const baseMonths = steps
  const complexity = idea.length > 150 ? 2 : 1

  return `${baseMonths}-${baseMonths + complexity} tháng`
}

